import { useEffect, useRef, useState } from 'react';
import { AlchemySection } from './components/AlchemySection';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { Navbar } from './components/Navbar';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ReservationModal, TimeSlot } from './components/ReservationModal';
import { TastingFlightSection } from './components/TastingFlightSection';
import { Toast } from './components/Toast';
import { CartItem, MenuItem } from './data/menuData';

const CART_STORAGE_KEY = 'kesar_crumb_cart_v1';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReserveOpen, setIsReserveOpen] = useState(false);
  const [defaultReserveSlot, setDefaultReserveSlot] = useState<TimeSlot>(
    'Morning Bake (8:00 AM – 11:00 AM)'
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleAddToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((entry) => entry.item.id === item.id);
      if (existing) {
        return prev.map((entry) =>
          entry.item.id === item.id
            ? { ...entry, quantity: entry.quantity + 1 }
            : entry
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
    showToast(`Added ${item.name} to your bag`);
  };

  const handleUpdateQuantity = (itemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((entry) =>
          entry.item.id === itemId
            ? { ...entry, quantity: entry.quantity + delta }
            : entry
        )
        .filter((entry) => entry.quantity > 0)
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCart((prev) => prev.filter((entry) => entry.item.id !== itemId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const openReservation = (slot: TimeSlot = 'Morning Bake (8:00 AM – 11:00 AM)') => {
    setDefaultReserveSlot(slot);
    setIsReserveOpen(true);
  };

  const totalCartItems = cart.reduce((sum, entry) => sum + entry.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#1E1815]">
      <Navbar
        cartCount={totalCartItems}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReserve={() => openReservation('Morning Bake (8:00 AM – 11:00 AM)')}
      />

      <main className="flex-1">
        <Hero onOpenReserve={() => openReservation('Morning Bake (8:00 AM – 11:00 AM)')} />

        <MenuSection
          cart={cart}
          onAddToCart={handleAddToCart}
          onUpdateQuantity={handleUpdateQuantity}
        />

        <AlchemySection />

        <TastingFlightSection
          onReserveHighTea={() => openReservation('Afternoon Chai (2:00 PM – 5:30 PM)')}
          onAddFlightToCart={handleAddToCart}
        />
      </main>

      <Footer onOpenReserve={() => openReservation('Morning Bake (8:00 AM – 11:00 AM)')} />

      <CartDrawer
        isOpen={isCartOpen}
        cart={cart}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      <ReservationModal
        isOpen={isReserveOpen}
        defaultSlot={defaultReserveSlot}
        onClose={() => setIsReserveOpen(false)}
      />

      <Toast
        message={toastMessage}
        onDismiss={() => setToastMessage(null)}
        onViewCart={() => setIsCartOpen(true)}
      />

      <OfflineIndicator />
    </div>
  );
}
