export type MenuCategory =
  | 'All'
  | 'Viennoiserie & Bakes'
  | 'Small Plates'
  | 'Specialty Coffee & Chai'
  | 'Signature Desserts';

export type DietaryTag =
  | 'Eggless'
  | 'Contains Nuts'
  | "Chef's Signature"
  | 'Spiced';

export interface MenuItem {
  id: string;
  code: string;
  name: string;
  price: number;
  category: Exclude<MenuCategory, 'All'>;
  pairing: string;
  description: string;
  tags: DietaryTag[];
  image: string;
  imageAlt: string;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
}

export interface AlchemyPrinciple {
  number: string;
  title: string;
  technique: string;
  ingredient: string;
  description: string;
  featuredDish: string;
}

export const HERO_IMAGE = '/src/assets/images/hero_kesar_crumb_1795245093998.jpg';
export const ALCHEMY_IMAGE = '/src/assets/images/alchemy_spices_craft_1795245092890.jpg';
export const HIGH_TEA_IMAGE = '/src/assets/images/high_tea_spread_1795245093479.jpg';

export const MENU_CATEGORIES: MenuCategory[] = [
  'All',
  'Viennoiserie & Bakes',
  'Small Plates',
  'Specialty Coffee & Chai',
  'Signature Desserts',
];

export const DIETARY_FILTERS: DietaryTag[] = [
  'Eggless',
  'Contains Nuts',
  "Chef's Signature",
  'Spiced',
];

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'gulkand-pistachio-croissant',
    code: 'KC-01',
    name: 'Gulkand & Pistachio Twice-Baked Croissant',
    price: 390,
    category: 'Viennoiserie & Bakes',
    pairing: 'French Lamination × Pushkar Rose',
    description:
      '72-hour cultured butter croissant soaked in Damask rose syrup, filled with sun-cooked gulkand frangipane and crowned with roasted Iranian pistachios.',
    tags: ['Eggless', 'Contains Nuts', "Chef's Signature"],
    image: '/src/assets/images/pastry_rose_croissant_1795245093927.jpg',
    imageAlt: 'Golden twice-baked croissant topped with crushed pistachios and dried rose petals on stoneware',
  },
  {
    id: 'truffle-kulcha-brioche',
    code: 'KC-02',
    name: 'Chilli Cheese & Truffle Kulcha Brioche',
    price: 420,
    category: 'Viennoiserie & Bakes',
    pairing: 'Feuilletée Dough × Old Delhi Tandoor',
    description:
      'Pull-apart laminated brioche stuffed with aged cheddar, black truffle butter, charred green chilli oil, and toasted kalonji nigella seeds.',
    tags: ['Spiced', "Chef's Signature"],
    image: '/src/assets/images/pastry_kulcha_brioche_1795245093632.jpg',
    imageAlt: 'Warm laminated chilli cheese and black truffle kulcha brioche pulled open with melted cheese',
  },
  {
    id: 'kesar-kouign-amann',
    code: 'KC-03',
    name: 'Kashmiri Saffron & Almond Kouign-Amann',
    price: 360,
    category: 'Viennoiserie & Bakes',
    pairing: 'Breton Caramel × Pampore Kesar',
    description:
      'Crisp caramelized sugar crust enveloping tender saffron-infused pastry layers and toasted Mamra almond slivers.',
    tags: ['Eggless', 'Contains Nuts'],
    image: '/src/assets/images/pastry_rose_croissant_1795245093927.jpg',
    imageAlt: 'Caramelized saffron almond pastry dusted with delicate botanicals',
  },
  {
    id: 'avocado-tamarind-tartine',
    code: 'KC-04',
    name: 'Avocado & Tamarind Sev Tartine',
    price: 480,
    category: 'Small Plates',
    pairing: 'Country Levain × Bombay Chaat',
    description:
      'Charred naturally leavened sourdough topped with whipped avocado mousse, sticky dates-tamarind reduction, pickled shallots, and crisp chickpea sev.',
    tags: ['Eggless', 'Spiced'],
    image: '/src/assets/images/plate_tamarind_tartine_1795245092745.jpg',
    imageAlt: 'Charred sourdough tartine with whipped avocado, tamarind glaze, chickpea sev, and cilantro blossoms',
  },
  {
    id: 'burrata-bharta-crostini',
    code: 'KC-05',
    name: 'Artisanal Burrata & Smoked Bharta Crostini',
    price: 540,
    category: 'Small Plates',
    pairing: 'Fresh Stracciatella × Charcoal Roast',
    description:
      'Creamy hand-pulled burrata served over flame-charred heirloom eggplant relish, garlic confit oil, and toasted sesame sourdough.',
    tags: ['Eggless', 'Spiced', "Chef's Signature"],
    image: '/src/assets/images/plate_tamarind_tartine_1795245092745.jpg',
    imageAlt: 'Artisanal sourdough small plate garnished with roasted vegetables and herbs',
  },
  {
    id: 'lotus-pepper-slider',
    code: 'KC-06',
    name: 'Crispy Lotus Stem & Black Pepper Brioche',
    price: 490,
    category: 'Small Plates',
    pairing: 'Toasted Brioche × Tellicherry Glaze',
    description:
      'Crisp honey-pepper lotus stem, curry leaf aioli, and pickled mustard greens tucked inside our house-baked mini brioche.',
    tags: ['Eggless', 'Spiced'],
    image: '/src/assets/images/pastry_kulcha_brioche_1795245093632.jpg',
    imageAlt: 'Savory toasted brioche infused with roasted spices and herbs',
  },
  {
    id: 'jaggery-sea-salt-cortado',
    code: 'KC-07',
    name: 'Jaggery & Sea Salt Cortado',
    price: 290,
    category: 'Specialty Coffee & Chai',
    pairing: 'Chikmagalur Roast × Organic Palm Gur',
    description:
      'Double ristretto of estate-grown Chikmagalur Arabica balanced with velvety microfoam, melted palm jaggery syrup, and Konkan sea salt.',
    tags: ['Eggless', "Chef's Signature"],
    image: '/src/assets/images/drink_kaapi_cortado_1795245094137.jpg',
    imageAlt: 'Jaggery and sea salt cortado in a fluted glass beside iced cardamom cold brew',
  },
  {
    id: 'cardamom-saffron-cold-brew',
    code: 'KC-08',
    name: 'Cardamom & Saffron Cold Brew',
    price: 340,
    category: 'Specialty Coffee & Chai',
    pairing: '18-Hour Steep × Malabar Elaichi',
    description:
      'Coarse-ground Coorg single-origin cold steeped for 18 hours with crushed green cardamom pods, poured over a saffron-infused crystal ice sphere.',
    tags: ['Eggless', 'Spiced'],
    image: '/src/assets/images/drink_kaapi_cortado_1795245094137.jpg',
    imageAlt: 'Crystal glass of cardamom cold brew coffee with a golden saffron ice sphere',
  },
  {
    id: 'assam-masala-chai-latte',
    code: 'KC-09',
    name: 'Smoked Assam Masala Chai Latte',
    price: 260,
    category: 'Specialty Coffee & Chai',
    pairing: 'Second-Flush Assam × Whole Mortar Spice',
    description:
      'Malty Upper Assam orthodox leaf simmered with freshly pounded ginger, green cardamom, cinnamon bark, and star anise, finished with steamed milk.',
    tags: ['Eggless', 'Spiced'],
    image: '/src/assets/images/drink_masala_chai_1795245093858.jpg',
    imageAlt: 'Masala chai latte in dark stoneware beside a brass mortar of whole spices',
  },
  {
    id: 'filter-kaapi-tiramisu',
    code: 'KC-10',
    name: 'Filter Kaapi Mascarpone Tiramisu',
    price: 520,
    category: 'Signature Desserts',
    pairing: 'Venetian Cream × Kumbakonam Decoction',
    description:
      'Savoiardi sponge steeped in traditional brass-filter chicory coffee decoction, layered with whipped mascarpone and roasted hazelnut cocoa dust.',
    tags: ['Contains Nuts', "Chef's Signature"],
    image: '/src/assets/images/dessert_kaapi_tiramisu_1795245093760.jpg',
    imageAlt: 'Layered Filter Kaapi mascarpone tiramisu dusted with dark cocoa and roasted hazelnuts',
  },
  {
    id: 'saffron-rasmalai-tres-leches',
    code: 'KC-11',
    name: 'Saffron Rasmalai Tres Leches',
    price: 490,
    category: 'Signature Desserts',
    pairing: 'Three-Milk Sponge × Kashmiri Kesar',
    description:
      'Featherlight vanilla bean sponge drenched in cardamom-saffron rabri milk, crowned with torched mascarpone chantilly and pistachio crumble.',
    tags: ['Eggless', 'Contains Nuts', "Chef's Signature"],
    image: '/src/assets/images/dessert_rasmalai_leches_1795245093082.jpg',
    imageAlt: 'Slice of saffron rasmalai tres leches cake garnished with silver leaf and crushed pistachios',
  },
  {
    id: 'masala-chai-basque-cheesecake',
    code: 'KC-12',
    name: 'Masala Chai Burnt Basque Cheesecake',
    price: 510,
    category: 'Signature Desserts',
    pairing: 'San Sebastián Bake × Assam Reduction',
    description:
      'High-heat caramelized crust yielding to a custard-soft spiced cream cheese center steeped in reduced Assam masala chai and Madagascar vanilla.',
    tags: ['Spiced'],
    image: '/src/assets/images/dessert_rasmalai_leches_1795245093082.jpg',
    imageAlt: 'Caramelized burnt Basque cheesecake slice infused with spiced tea and cream',
  },
];

export const HIGH_TEA_FLIGHT_ITEM: MenuItem = {
  id: 'indo-french-high-tea-flight',
  code: 'KC-HT',
  name: "Chef's Three-Tier Indo-French High Tea (For Two)",
  price: 2400,
  category: 'Signature Desserts',
  pairing: 'Three-Tier Tasting × Single-Estate Chai Service',
  description:
    'Warm truffle kulcha bites, tamarind avocado tartines, saffron financiers, miniature gulkand croissants, and two pots of Assam masala chai or Chikmagalur pour-over.',
  tags: ['Contains Nuts', "Chef's Signature", 'Spiced'],
  image: '/src/assets/images/high_tea_spread_1795245093479.jpg',
  imageAlt: 'Three-tier brass high tea stand with savory kulchas, saffron tarts, financiers, and chai pots',
};

export const ALCHEMY_PRINCIPLES: AlchemyPrinciple[] = [
  {
    number: '01',
    title: 'French Lamination + Kashmiri Saffron',
    technique: '27-Fold Cultured Butter Dough',
    ingredient: 'Grade-A Pampore Kesar',
    description:
      'We cold-ferment stone-milled French T55 flour for 48 hours before folding in Normandy-style cultured butter infused with steeped Kashmiri saffron strands and wild honey.',
    featuredDish: 'Gulkand & Pistachio Twice-Baked Croissant',
  },
  {
    number: '02',
    title: 'Single-Origin Chikmagalur Beans + Palm Jaggery',
    technique: 'Precision Ristretto & 18-Hr Steep',
    ingredient: 'Unrefined Konkan Palm Gur',
    description:
      'Shade-grown Arabica from Karnataka’s Bababudangiri hills is medium-roasted in small batches to highlight dark cocoa notes, naturally rounded with mineral-rich palm jaggery.',
    featuredDish: 'Jaggery & Sea Salt Cortado',
  },
  {
    number: '03',
    title: 'Basque Baking + Assam Masala Reduction',
    technique: 'High-Heat Caramelized Custard Bake',
    ingredient: 'Freshly Pounded Whole Spices',
    description:
      'Whole green cardamom, Tellicherry black pepper, and cinnamon bark are toasted dry in brass pans before steeping into double cream for a deeply aromatic Basque custard.',
    featuredDish: 'Masala Chai Burnt Basque Cheesecake',
  },
];
