import { useState } from 'react';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenReserve: () => void;
}

const NAV_LINKS = [
  { label: 'Our Story', href: '#our-story' },
  { label: 'The Fusion Menu', href: '#fusion-menu' },
  { label: 'Tasting Flight', href: '#tasting-flight' },
  { label: 'Visit Us', href: '#visit-us' },
];

export function Navbar({ cartCount, onOpenCart, onOpenReserve }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 h-16 bg-[#FAF7F2]/88 backdrop-blur-md border-b border-[#1E1815]/10">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#top"
          className="font-serif text-2xl font-semibold tracking-tight text-[#1E1815] whitespace-nowrap shrink-0 hover:text-[#C85A32] transition-colors"
        >
          Kesar &amp; Crumb
        </a>

        {/* Zone 2: Single-line Navigation Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#1E1815]/75"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 whitespace-nowrap shrink-0 hover:text-[#1E1815] transition-colors after:content-[''] after:absolute after:left-0 after:bottom-0 after:w-full after:h-[1px] after:bg-[#C85A32] after:scale-x-0 hover:after:scale-x-100 after:origin-left after:transition-transform after:duration-200"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Action & Order Bag */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenCart}
            aria-label={`Open order bag, ${cartCount} items`}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-[#1E1815] border border-[#1E1815]/20 rounded-md hover:border-[#1E1815]/50 bg-[#FAF7F2] transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
          >
            <ShoppingBag className="w-4 h-4 text-[#C85A32]" strokeWidth={1.75} />
            <span>Order Bag</span>
            <span className="font-mono tabular-nums text-[#1E1815]/80">({cartCount})</span>
          </button>

          <button
            type="button"
            onClick={onOpenReserve}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
          >
            Reserve a Table
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 text-[#1E1815] border border-[#1E1815]/15 rounded-md hover:bg-[#F2ECE1] transition-colors cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Collapsible Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden bg-[#FAF7F2] border-b border-[#1E1815]/15 px-4 py-5 shadow-lg">
          <nav aria-label="Mobile Navigation" className="flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="py-2.5 text-base font-medium text-[#1E1815] border-b border-[#1E1815]/10"
              >
                {link.label}
              </a>
            ))}
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenReserve();
              }}
              className="mt-2 w-full py-3 px-4 text-sm font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[44px]"
            >
              Reserve a Table
            </button>
            <PWAInstallButton
              variant="drawer"
              onActionComplete={() => setMobileOpen(false)}
            />
          </nav>
        </div>
      )}
    </header>
  );
}
