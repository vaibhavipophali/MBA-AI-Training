import { FormEvent, useEffect, useState } from 'react';
import { CheckCircle2, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { CartItem } from '../data/menuData';
import { EditorialImage } from './EditorialImage';

interface CartDrawerProps {
  isOpen: boolean;
  cart: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
}

const PICKUP_WINDOWS = [
  'Ready in 20 minutes',
  'Morning Bake (8:30 AM)',
  'Afternoon Chai (3:30 PM)',
];

export function CartDrawer({
  isOpen,
  cart,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [customerNote, setCustomerNote] = useState('');
  const [pickupWindow, setPickupWindow] = useState(PICKUP_WINDOWS[0]);
  const [guestName, setGuestName] = useState('');
  const [error, setError] = useState('');
  const [orderConfirmation, setOrderConfirmation] = useState<{
    orderId: string;
    total: number;
    pickup: string;
    note: string;
    name: string;
  } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, entry) => sum + entry.item.price * entry.quantity, 0);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;

  const handleCheckout = (e: FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) {
      setError('Please enter your name for pickup counter collection.');
      return;
    }
    setError('');
    const orderNum = Math.floor(1000 + Math.random() * 9000);
    setOrderConfirmation({
      orderId: `KC-${orderNum}`,
      total,
      pickup: pickupWindow,
      note: customerNote,
      name: guestName.trim(),
    });
    onClearCart();
  };

  const closeAndResetReceipt = () => {
    setOrderConfirmation(null);
    setError('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-[#1E1815]/55 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeAndResetReceipt();
      }}
    >
      <aside className="w-full max-w-md h-full bg-[#FAF7F2] border-l border-[#1E1815]/15 flex flex-col shadow-2xl">
        {/* Drawer Header */}
        <div className="px-6 py-5 border-b border-[#1E1815]/12 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#C85A32]" strokeWidth={1.75} />
            <h2 id="cart-drawer-title" className="font-serif text-2xl font-semibold text-[#1E1815]">
              Pre-Order Bag
            </h2>
          </div>

          <button
            type="button"
            onClick={closeAndResetReceipt}
            aria-label="Close order bag"
            className="p-2 text-[#1E1815]/60 hover:text-[#1E1815] hover:bg-[#F2ECE1] rounded-md transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        {orderConfirmation ? (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <CheckCircle2 className="w-7 h-7 text-[#4A5D4E] shrink-0" />
                <div>
                  <p className="font-mono text-xs text-[#4A5D4E]">
                    Order {orderConfirmation.orderId} Confirmed
                  </p>
                  <h3 className="font-serif text-2xl font-semibold text-[#1E1815]">
                    Preparing your bake, {orderConfirmation.name}.
                  </h3>
                </div>
              </div>

              <div className="bg-[#F2ECE1] border border-[#1E1815]/12 rounded-lg p-5 space-y-3 text-sm">
                <div className="flex justify-between gap-4 border-b border-[#1E1815]/10 pb-2.5">
                  <span className="text-[#1E1815]/65">Collection Window</span>
                  <span className="font-mono font-medium">{orderConfirmation.pickup}</span>
                </div>
                <div className="flex justify-between gap-4 border-b border-[#1E1815]/10 pb-2.5">
                  <span className="text-[#1E1815]/65">Pickup Counter</span>
                  <span className="font-medium">14 Pali Hill Courtyard</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-[#1E1815]/65">Total Due at Counter</span>
                  <span className="font-mono font-semibold tabular-nums">
                    ₹{orderConfirmation.total}
                  </span>
                </div>
                {orderConfirmation.note && (
                  <div className="pt-2.5 border-t border-[#1E1815]/10">
                    <span className="text-xs text-[#1E1815]/65 block mb-1">Kitchen Note</span>
                    <p className="text-xs text-[#1E1815]">{orderConfirmation.note}</p>
                  </div>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={closeAndResetReceipt}
              className="w-full py-3 px-4 text-sm font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[44px]"
            >
              Return to Menu
            </button>
          </div>
        ) : cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <ShoppingBag className="w-10 h-10 text-[#1E1815]/25 mb-4" strokeWidth={1.25} />
            <h3 className="font-serif text-2xl font-semibold text-[#1E1815] mb-2">
              Your order bag is empty
            </h3>
            <p className="text-sm text-[#1E1815]/65 max-w-xs mb-6">
              Add laminated viennoiserie, small plates, or specialty pours from the menu for counter
              pickup.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[44px]"
            >
              Browse the Menu
            </button>
          </div>
        ) : (
          <form onSubmit={handleCheckout} className="flex-1 flex flex-col overflow-hidden" noValidate>
            {/* Scrollable Line Items & Notes */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
              <div className="divide-y divide-[#1E1815]/10">
                {cart.map(({ item, quantity }) => (
                  <div key={item.id} className="py-4 first:pt-0 flex gap-4">
                    <div className="w-18 h-14 rounded-md overflow-hidden shrink-0 border border-[#1E1815]/10">
                      <EditorialImage
                        src={item.image}
                        alt={item.imageAlt}
                        containerClassName="w-full h-full"
                        className="w-full h-full object-cover"
                        fallbackTitle={item.name}
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif text-base font-semibold text-[#1E1815] leading-snug">
                          {item.name}
                        </h3>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.id)}
                          aria-label={`Remove ${item.name}`}
                          className="p-1 text-[#1E1815]/40 hover:text-[#C85A32] transition-colors cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="mt-2.5 flex items-center justify-between">
                        <div className="inline-flex items-center border border-[#1E1815]/20 rounded bg-[#F2ECE1]/60">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            aria-label={`Decrease ${item.name}`}
                            className="p-1.5 text-[#1E1815] hover:text-[#C85A32] cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 font-mono text-xs tabular-nums">{quantity}</span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            aria-label={`Increase ${item.name}`}
                            className="p-1.5 text-[#1E1815] hover:text-[#C85A32] cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <span className="font-mono text-sm font-medium text-[#1E1815] tabular-nums">
                          ₹{item.price * quantity}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pickup Window */}
              <div className="pt-4 border-t border-[#1E1815]/12">
                <label className="block text-xs font-mono text-[#1E1815]/75 mb-2">
                  Pickup Time
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {PICKUP_WINDOWS.map((win) => (
                    <button
                      key={win}
                      type="button"
                      onClick={() => setPickupWindow(win)}
                      className={`text-left px-3.5 py-2 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                        pickupWindow === win
                          ? 'bg-[#1E1815] text-[#FAF7F2] border-[#1E1815]'
                          : 'bg-[#F2ECE1]/60 text-[#1E1815] border-[#1E1815]/15 hover:border-[#1E1815]/40'
                      }`}
                    >
                      {win}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Barista / Kitchen Note */}
              <div>
                <label
                  htmlFor="kitchen-note"
                  className="block text-xs font-mono text-[#1E1815]/75 mb-1.5"
                >
                  Barista &amp; Kitchen Note
                </label>
                <textarea
                  id="kitchen-note"
                  rows={2}
                  value={customerNote}
                  onChange={(e) => setCustomerNote(e.target.value)}
                  placeholder="e.g., Extra hot cortado, less sweet, warm croissant before pickup"
                  className="w-full px-3 py-2 text-sm bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] placeholder:text-[#1E1815]/45 resize-none"
                />
              </div>

              {/* Name for Pickup */}
              <div>
                <label
                  htmlFor="pickup-name"
                  className="block text-xs font-mono text-[#1E1815]/75 mb-1.5"
                >
                  Name for Counter Pickup
                </label>
                <input
                  id="pickup-name"
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="Meera Kapoor"
                  className="w-full px-3.5 py-2 text-sm bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] min-h-[42px]"
                  required
                />
              </div>

              {error && (
                <p role="alert" className="text-xs font-medium text-[#C85A32]">
                  {error}
                </p>
              )}
            </div>

            {/* Totals & Checkout */}
            <div className="px-6 py-5 bg-[#F2ECE1] border-t border-[#1E1815]/12 space-y-4">
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between text-[#1E1815]/70">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums">₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-[#1E1815]/70">
                  <span>GST (5%)</span>
                  <span className="font-mono tabular-nums">₹{tax}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#1E1815]/12 text-base font-semibold text-[#1E1815]">
                  <span>Total</span>
                  <span className="font-mono tabular-nums">₹{total}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-4 text-sm font-medium text-[#FAF7F2] bg-[#C85A32] hover:bg-[#1E1815] rounded-md transition-colors cursor-pointer min-h-[44px]"
              >
                Place Pickup Order · ₹{total}
              </button>
            </div>
          </form>
        )}
      </aside>
    </div>
  );
}
