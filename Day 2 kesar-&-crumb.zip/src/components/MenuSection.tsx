import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Minus, Plus, Search, X } from 'lucide-react';
import {
  CartItem,
  DIETARY_FILTERS,
  DietaryTag,
  MENU_CATEGORIES,
  MENU_ITEMS,
  MenuCategory,
  MenuItem,
} from '../data/menuData';
import { EditorialImage } from './EditorialImage';

interface MenuSectionProps {
  cart: CartItem[];
  onAddToCart: (item: MenuItem) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
}

export function MenuSection({
  cart,
  onAddToCart,
  onUpdateQuantity,
}: MenuSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory>('All');
  const [selectedTags, setSelectedTags] = useState<DietaryTag[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleTag = (tag: DietaryTag) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const resetFilters = () => {
    setSelectedCategory('All');
    setSelectedTags([]);
    setSearchQuery('');
  };

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return MENU_ITEMS.filter((item) => {
      const matchesCategory =
        selectedCategory === 'All' || item.category === selectedCategory;
      const matchesTags =
        selectedTags.length === 0 ||
        selectedTags.every((tag) => item.tags.includes(tag));
      const matchesQuery =
        q === '' ||
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.pairing.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q);
      return matchesCategory && matchesTags && matchesQuery;
    });
  }, [selectedCategory, selectedTags, searchQuery]);

  const getItemQuantity = (id: string) => {
    const found = cart.find((c) => c.item.id === id);
    return found ? found.quantity : 0;
  };

  return (
    <section id="fusion-menu" className="py-16 lg:py-24 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header + Search */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="font-mono text-xs text-[#C85A32] tracking-wide mb-2">
              Seasonal Patisserie &amp; Beverage Ledger
            </p>
            <h2
              className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#1E1815] tracking-tight leading-tight"
              style={{ textWrap: 'balance' }}
            >
              The Fusion Menu
            </h2>
            <p className="mt-3 text-base text-[#1E1815]/70 leading-relaxed">
              Every pastry, tartine, and pour bridges classical European technique with regional
              Indian terroir. Select items to pre-order for courtyard pickup.
            </p>
          </div>

          {/* Search Input */}
          <div className="w-full lg:w-80 relative shrink-0">
            <Search
              className="w-4 h-4 text-[#1E1815]/45 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              strokeWidth={1.75}
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search saffron, kulcha, kaapi..."
              aria-label="Search menu items"
              className="w-full pl-10 pr-9 py-2.5 text-sm bg-[#F2ECE1]/70 border border-[#1E1815]/15 rounded-md text-[#1E1815] placeholder:text-[#1E1815]/45 focus:border-[#C85A32] focus:bg-[#FAF7F2] transition-colors min-h-[44px]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#1E1815]/50 hover:text-[#1E1815] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Category Tabs with Sliding Indicator */}
        <div
          role="tablist"
          aria-label="Menu Categories"
          className="flex items-center gap-2 overflow-x-auto pb-3 border-b border-[#1E1815]/12 mb-5 no-scrollbar"
        >
          {MENU_CATEGORIES.map((category) => {
            const isActive = selectedCategory === category;
            return (
              <button
                key={category}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => setSelectedCategory(category)}
                className={`relative px-4 py-2.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px] ${
                  isActive
                    ? 'text-[#FAF7F2]'
                    : 'text-[#1E1815]/70 hover:text-[#1E1815] hover:bg-[#F2ECE1]/70'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="menu-category-indicator"
                    transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                    className="absolute inset-0 bg-[#1E1815] rounded-md -z-0"
                  />
                )}
                <span className="relative z-10">{category}</span>
              </button>
            );
          })}
        </div>

        {/* Interactive Dietary & Flavor Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Dietary and flavor filters">
            <span className="text-xs font-mono text-[#1E1815]/55 mr-1">Filter by:</span>
            {DIETARY_FILTERS.map((tag) => {
              const active = selectedTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  aria-pressed={active}
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
                    active
                      ? 'bg-[#4A5D4E] text-[#FAF7F2] border-[#4A5D4E]'
                      : 'bg-transparent text-[#1E1815]/75 border-[#1E1815]/18 hover:border-[#1E1815]/45'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
            {(selectedTags.length > 0 || selectedCategory !== 'All' || searchQuery) && (
              <button
                type="button"
                onClick={resetFilters}
                className="px-2.5 py-1.5 text-xs font-medium text-[#C85A32] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
              >
                Reset
              </button>
            )}
          </div>

          <p className="font-mono text-xs text-[#1E1815]/60 tabular-nums">
            Showing {filteredItems.length} of {MENU_ITEMS.length} offerings
          </p>
        </div>

        {/* Menu Grid or Empty State */}
        {filteredItems.length === 0 ? (
          <div className="bg-[#F2ECE1] border border-[#1E1815]/12 rounded-xl py-16 px-6 text-center">
            <p className="font-serif text-2xl font-semibold text-[#1E1815] mb-2">
              No offerings match your current selection
            </p>
            <p className="text-sm text-[#1E1815]/65 mb-6 max-w-md mx-auto">
              Try clearing one of the dietary filters or searching for another ingredient like
              saffron, cardamom, or brioche.
            </p>
            <button
              type="button"
              onClick={resetFilters}
              className="px-5 py-2.5 text-sm font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[44px]"
            >
              Show All Offerings
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filteredItems.map((item) => {
              const qtyInCart = getItemQuantity(item.id);
              return (
                <article
                  key={item.id}
                  className="group flex flex-col bg-[#F2ECE1] border border-[#1E1815]/10 rounded-xl overflow-hidden transition-transform duration-200 hover:-translate-y-0.5"
                >
                  {/* 4:3 Photography */}
                  <div className="aspect-[4/3] w-full overflow-hidden">
                    <EditorialImage
                      src={item.image}
                      alt={item.imageAlt}
                      containerClassName="w-full h-full"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      fallbackTitle={item.name}
                    />
                  </div>

                  {/* Card Body */}
                  <div className="flex-1 flex flex-col justify-between p-6">
                    <div>
                      {/* Unboxed Metadata Line */}
                      <div className="flex items-center gap-2 text-xs font-mono text-[#4A5D4E] mb-2 truncate">
                        <span className="shrink-0">{item.code}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">{item.pairing}</span>
                      </div>

                      {/* Title & Price */}
                      <div className="flex items-start justify-between gap-4 mb-2.5">
                        <h3 className="font-serif text-xl font-semibold text-[#1E1815] leading-snug">
                          {item.name}
                        </h3>
                        <span className="font-mono text-base font-medium text-[#1E1815] tabular-nums shrink-0 pt-0.5">
                          ₹{item.price}
                        </span>
                      </div>

                      <p className="text-sm text-[#1E1815]/75 leading-relaxed mb-4">
                        {item.description}
                      </p>
                    </div>

                    {/* Footer: Dietary Metadata & Add CTA */}
                    <div className="pt-4 border-t border-[#1E1815]/10 flex items-center justify-between gap-3">
                      <p className="text-xs font-mono text-[#1E1815]/60 truncate">
                        {item.tags.join(' · ')}
                      </p>

                      {qtyInCart === 0 ? (
                        <button
                          type="button"
                          onClick={() => onAddToCart(item)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
                        >
                          <Plus className="w-3.5 h-3.5" strokeWidth={2} />
                          <span>Add to Order</span>
                        </button>
                      ) : (
                        <div className="inline-flex items-center border border-[#1E1815]/25 rounded-md bg-[#FAF7F2] shrink-0">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            aria-label={`Decrease quantity of ${item.name}`}
                            className="p-2 text-[#1E1815] hover:text-[#C85A32] transition-colors cursor-pointer min-h-[40px] min-w-[36px] flex items-center justify-center"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-2.5 font-mono text-xs font-medium tabular-nums text-[#1E1815]">
                            {qtyInCart}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            aria-label={`Increase quantity of ${item.name}`}
                            className="p-2 text-[#1E1815] hover:text-[#C85A32] transition-colors cursor-pointer min-h-[40px] min-w-[36px] flex items-center justify-center"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
