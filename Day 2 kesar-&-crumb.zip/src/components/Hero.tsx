import { ArrowRight, Calendar } from 'lucide-react';
import { HERO_IMAGE } from '../data/menuData';
import { EditorialImage } from './EditorialImage';
import { PWAInstallButton } from './PWAInstallButton';

interface HeroProps {
  onOpenReserve: () => void;
}

const CRAFT_HIGHLIGHTS = [
  { metric: '07:00 AM', label: 'First Morning Bake Out of the Deck Oven' },
  { metric: '72 Hours', label: 'Cold-Fermented Cultured Butter Lamination' },
  { metric: '100% Estate', label: 'Single-Origin Chikmagalur & Assam Harvest' },
  { metric: 'Daily Service', label: 'Indo-French Courtyard High Tea for Two' },
];

export function Hero({ onOpenReserve }: HeroProps) {
  return (
    <section id="top" className="relative overflow-hidden bg-[#FAF7F2] pt-10 pb-12 sm:pt-14 lg:pt-16 lg:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Editorial Narrative & CTAs */}
          <div className="lg:col-span-6 flex flex-col justify-between py-2 lg:py-6">
            <div>
              <p className="font-mono text-xs tracking-wide text-[#4A5D4E] mb-5">
                Indo-French Patisserie · Bandra West, Mumbai
              </p>

              <h1
                className="font-serif font-semibold text-[#1E1815] tracking-tight leading-[1.03] mb-6"
                style={{ fontSize: 'clamp(2.65rem, 4.8vw, 4.4rem)', textWrap: 'balance' }}
              >
                Old-World Spice.
                <br />
                <span className="italic font-medium text-[#C85A32]">New-World</span> Craft.
              </h1>

              <p className="text-base sm:text-lg text-[#1E1815]/75 leading-relaxed max-w-xl mb-8">
                A quiet sanctuary where 27-fold French lamination meets sun-cured Kashmiri saffron,
                palm jaggery, and estate-roasted Chikmagalur coffee—baked fresh each dawn in our
                sunlit courtyard.
              </p>

              <div className="flex flex-wrap items-center gap-4">
                <a
                  href="#fusion-menu"
                  className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-medium text-[#FAF7F2] bg-[#C85A32] hover:bg-[#1E1815] rounded-md transition-colors duration-200 whitespace-nowrap shrink-0 min-h-[44px]"
                >
                  <span>Explore the Menu</span>
                  <ArrowRight className="w-4 h-4" strokeWidth={1.75} />
                </a>

                <button
                  type="button"
                  onClick={onOpenReserve}
                  className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-medium text-[#1E1815] bg-transparent border border-[#1E1815]/25 hover:border-[#1E1815] hover:bg-[#F2ECE1] rounded-md transition-colors duration-200 whitespace-nowrap shrink-0 cursor-pointer min-h-[44px]"
                >
                  <Calendar className="w-4 h-4 text-[#C85A32]" strokeWidth={1.75} />
                  <span>Book a Table</span>
                </button>
              </div>

              <div className="mt-4">
                <PWAInstallButton variant="hero" />
              </div>
            </div>

            {/* Quiet Culinary Provenance Note */}
            <div className="mt-10 pt-6 border-t border-[#1E1815]/10 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-[#1E1815]/65 font-mono">
              <span>Small-Batch Stone-Milled Flour</span>
              <span aria-hidden="true">·</span>
              <span>Pampore Saffron &amp; Pushkar Gulkand</span>
              <span aria-hidden="true">·</span>
              <span>Brass-Filter Decoction</span>
            </div>
          </div>

          {/* Right Column: Arch-Framed Visual Showcase */}
          <div className="lg:col-span-6 flex items-stretch">
            <div className="relative w-full min-h-[380px] sm:min-h-[460px] lg:min-h-[540px]">
              <div
                className="w-full h-full overflow-hidden border border-[#D4A359]/40 bg-[#F2ECE1] shadow-sm"
                style={{ borderRadius: '200px 200px 16px 16px' }}
              >
                <EditorialImage
                  src={HERO_IMAGE}
                  alt="Artisanal pistachio and rose petal croissant beside a stoneware filter kaapi cortado and Kashmiri saffron dish in sunlit courtyard"
                  containerClassName="w-full h-full"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.03]"
                  fallbackTitle="Kesar & Crumb Courtyard"
                />
              </div>

              {/* Floating Editorial Bake Schedule Badge */}
              <div className="absolute bottom-5 left-5 sm:bottom-7 sm:left-7 bg-[#FAF7F2]/95 backdrop-blur-sm border border-[#D4A359]/50 rounded-md px-4 py-3 shadow-sm max-w-[260px]">
                <p className="font-mono text-[11px] text-[#C85A32] tracking-wide">
                  Daily Patisserie Schedule
                </p>
                <p className="font-serif text-lg font-semibold text-[#1E1815] leading-snug mt-0.5">
                  Freshly Baked at 7:00 AM Daily
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Craft Strip */}
        <div className="mt-12 lg:mt-16 border-y border-[#1E1815]/12 py-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {CRAFT_HIGHLIGHTS.map((item) => (
            <div key={item.metric} className="flex flex-col gap-1">
              <span className="font-mono text-sm font-medium text-[#C85A32] tabular-nums">
                {item.metric}
              </span>
              <span className="text-sm text-[#1E1815]/75 leading-snug">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
