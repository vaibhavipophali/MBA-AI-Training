import { useEffect, useState } from 'react';
import { Check, Copy, Download, MoreVertical, Share, Share2, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'hero' | 'drawer' | 'footer';
  onActionComplete?: () => void;
}

export function PWAInstallButton({
  variant = 'hero',
  onActionComplete,
}: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } =
    usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [activePlatform, setActivePlatform] = useState<'ios' | 'android'>('android');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const installUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/?install=1`
      : '';

  useEffect(() => {
    if (isIOS) {
      setActivePlatform('ios');
    } else if (isAndroid) {
      setActivePlatform('android');
    }
  }, [isIOS, isAndroid]);

  // Auto-open install sheet only when explicitly opened via /?install=1 link
  useEffect(() => {
    if (typeof window === 'undefined' || isInstalled) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('install') === '1') {
      setShowGuide(true);
    }
  }, [isInstalled]);

  useEffect(() => {
    if (!showGuide) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowGuide(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showGuide]);

  // Hide when already running as an installed standalone mobile app
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted && onActionComplete) {
        onActionComplete();
      }
      return;
    }
    setShowGuide(true);
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(installUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      setCopiedUrl(false);
    }
  };

  const handleShareLink = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'Kesar & Crumb — Café & Patisserie',
          text: 'Install the Kesar & Crumb mobile app for Indo-French viennoiserie, specialty coffee, and pre-orders.',
          url: installUrl,
        });
        return;
      } catch {
        // User cancelled or share unsupported, fall back to copy
      }
    }
    await handleCopyLink();
  };

  const buttonStyles = {
    hero: 'inline-flex items-center gap-2 text-xs font-mono text-[#1E1815]/80 hover:text-[#C85A32] underline-offset-4 hover:underline transition-colors cursor-pointer min-h-[40px]',
    drawer:
      'w-full py-3 px-4 text-sm font-medium text-[#1E1815] bg-[#F2ECE1] border border-[#1E1815]/20 hover:border-[#C85A32] rounded-md transition-colors flex items-center justify-center gap-2 cursor-pointer min-h-[44px]',
    footer:
      'inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-[#FAF7F2] border border-[#D4A359]/45 hover:border-[#D4A359] hover:bg-[#D4A359]/10 rounded-md transition-colors cursor-pointer min-h-[40px]',
  }[variant];

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={buttonStyles}
      >
        {isInstallable ? (
          <Download className="w-4 h-4 text-[#C85A32] shrink-0" strokeWidth={1.75} />
        ) : (
          <Smartphone className="w-4 h-4 text-[#C85A32] shrink-0" strokeWidth={1.75} />
        )}
        <span>
          {isInstallable
            ? 'Install Mobile App'
            : isIOS
            ? 'Install App on iPhone'
            : 'Install Android & iOS App'}
        </span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1E1815]/60 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowGuide(false);
          }}
        >
          <div className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-[#FAF7F2] border border-[#D4A359]/45 rounded-xl shadow-2xl p-6 text-[#1E1815]">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#1E1815]/12">
              <div>
                <p className="font-mono text-xs text-[#C85A32] tracking-wide mb-1">
                  Mobile App Installation
                </p>
                <h2
                  id="pwa-install-title"
                  className="font-serif text-2xl font-semibold text-[#1E1815]"
                >
                  Install Kesar &amp; Crumb
                </h2>
              </div>

              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close installation guide"
                className="p-2 text-[#1E1815]/60 hover:text-[#1E1815] hover:bg-[#F2ECE1] rounded-md transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-sm text-[#1E1815]/75 leading-relaxed mt-4 mb-4">
              Add Kesar &amp; Crumb directly to your phone&apos;s home screen for a full-screen
              app experience, saved order bag, and offline menu access.
            </p>

            {isInstallable && (
              <button
                type="button"
                onClick={install}
                className="w-full mb-5 py-3 px-4 text-sm font-medium text-[#FAF7F2] bg-[#C85A32] hover:bg-[#1E1815] rounded-md transition-colors flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
              >
                <Download className="w-4 h-4" />
                <span>Install Now</span>
              </button>
            )}

            {/* Direct Install Link Box */}
            <div className="mb-5 p-3 bg-[#F2ECE1] border border-[#1E1815]/12 rounded-lg">
              <p className="font-mono text-[11px] text-[#1E1815]/60 mb-1">
                Direct Mobile Install Link
              </p>
              <p className="font-mono text-xs text-[#1E1815] truncate select-all">
                {installUrl}
              </p>
            </div>

            {/* Platform Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-[#F2ECE1] rounded-lg mb-5">
              <button
                type="button"
                onClick={() => setActivePlatform('android')}
                className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer min-h-[38px] ${
                  activePlatform === 'android'
                    ? 'bg-[#1E1815] text-[#FAF7F2]'
                    : 'text-[#1E1815]/70 hover:text-[#1E1815]'
                }`}
              >
                Android (Chrome)
              </button>
              <button
                type="button"
                onClick={() => setActivePlatform('ios')}
                className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer min-h-[38px] ${
                  activePlatform === 'ios'
                    ? 'bg-[#1E1815] text-[#FAF7F2]'
                    : 'text-[#1E1815]/70 hover:text-[#1E1815]'
                }`}
              >
                iPhone &amp; iPad (Safari)
              </button>
            </div>

            {activePlatform === 'android' ? (
              <ol className="space-y-3 text-sm text-[#1E1815]/85 mb-6">
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">01.</span>
                  <span>
                    Open the install link in <strong>Google Chrome</strong> on your Android phone.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">02.</span>
                  <span className="flex items-center flex-wrap gap-1">
                    Tap the browser menu
                    <MoreVertical className="w-4 h-4 inline text-[#1E1815]" />
                    in the top-right corner.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">03.</span>
                  <span>
                    Tap <strong>Install app</strong> (or <strong>Add to Home screen</strong>) and
                    confirm.
                  </span>
                </li>
              </ol>
            ) : (
              <ol className="space-y-3 text-sm text-[#1E1815]/85 mb-6">
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">01.</span>
                  <span>
                    Open the install link in <strong>Safari</strong> on your iPhone or iPad.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">02.</span>
                  <span className="flex items-center flex-wrap gap-1">
                    Tap the <strong>Share</strong> icon
                    <Share className="w-4 h-4 inline text-[#C85A32]" />
                    at the bottom toolbar.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono text-xs text-[#C85A32] pt-0.5 shrink-0">03.</span>
                  <span>
                    Scroll down, tap <strong>Add to Home Screen</strong>, then tap{' '}
                    <strong>Add</strong>.
                  </span>
                </li>
              </ol>
            )}

            <div className="pt-4 border-t border-[#1E1815]/12 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1E1815] border border-[#1E1815]/20 hover:border-[#1E1815] rounded-md transition-colors cursor-pointer min-h-[40px]"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4A5D4E]" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#C85A32]" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleShareLink}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1E1815] border border-[#1E1815]/20 hover:border-[#1E1815] rounded-md transition-colors cursor-pointer min-h-[40px]"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#C85A32]" />
                  <span>Share</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="px-4 py-2 text-xs font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[40px]"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
