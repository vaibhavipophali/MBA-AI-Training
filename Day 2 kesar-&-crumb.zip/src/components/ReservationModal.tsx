import { FormEvent, useEffect, useState } from 'react';
import { Calendar, CheckCircle2, Clock, MapPin, Users, X } from 'lucide-react';

export type TimeSlot =
  | 'Morning Bake (8:00 AM – 11:00 AM)'
  | 'Afternoon Chai (2:00 PM – 5:30 PM)'
  | 'Evening Lounge (6:00 PM – 9:30 PM)';

export type SeatingArea = 'Sunlit Courtyard' | 'Espresso Bar' | 'Cozy Corner';

interface ReservationModalProps {
  isOpen: boolean;
  defaultSlot?: TimeSlot;
  onClose: () => void;
}

const TIME_SLOTS: { value: TimeSlot; label: string; sub: string }[] = [
  { value: 'Morning Bake (8:00 AM – 11:00 AM)', label: 'Morning Bake', sub: '8:00 AM – 11:00 AM' },
  { value: 'Afternoon Chai (2:00 PM – 5:30 PM)', label: 'Afternoon Chai', sub: '2:00 PM – 5:30 PM' },
  { value: 'Evening Lounge (6:00 PM – 9:30 PM)', label: 'Evening Lounge', sub: '6:00 PM – 9:30 PM' },
];

const SEATING_OPTIONS: { value: SeatingArea; note: string }[] = [
  { value: 'Sunlit Courtyard', note: 'Frangipani canopy & stone archways' },
  { value: 'Espresso Bar', note: 'Watch pour-overs & lamination' },
  { value: 'Cozy Corner', note: 'Velvet banquette indoors' },
];

function getTodayISODate() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function ReservationModal({
  isOpen,
  defaultSlot = 'Morning Bake (8:00 AM – 11:00 AM)',
  onClose,
}: ReservationModalProps) {
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState(getTodayISODate);
  const [timeSlot, setTimeSlot] = useState<TimeSlot>(defaultSlot);
  const [seating, setSeating] = useState<SeatingArea>('Sunlit Courtyard');
  const [guestName, setGuestName] = useState('');
  const [contact, setContact] = useState('');
  const [specialRequest, setSpecialRequest] = useState('');
  const [error, setError] = useState('');
  const [confirmationCode, setConfirmationCode] = useState<string | null>(null);

  useEffect(() => {
    setTimeSlot(defaultSlot);
  }, [defaultSlot]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) {
      setError('Please enter a name for the reservation.');
      return;
    }
    if (!contact.trim() || contact.trim().length < 6) {
      setError('Please enter a valid phone number or email address.');
      return;
    }
    setError('');
    const randomRef = Math.floor(1000 + Math.random() * 9000);
    setConfirmationCode(`KC-RES-${randomRef}`);
  };

  const resetAndClose = () => {
    setConfirmationCode(null);
    setError('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1E1815]/60 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reservation-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) resetAndClose();
      }}
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#FAF7F2] border border-[#D4A359]/40 rounded-xl shadow-2xl p-6 sm:p-8">
        <div className="flex items-start justify-between gap-4 pb-5 border-b border-[#1E1815]/12">
          <div>
            <p className="font-mono text-xs text-[#C85A32] tracking-wide mb-1">
              Courtyard Hospitality
            </p>
            <h2
              id="reservation-modal-title"
              className="font-serif text-2xl sm:text-3xl font-semibold text-[#1E1815]"
            >
              Reserve a Table
            </h2>
          </div>

          <button
            type="button"
            onClick={resetAndClose}
            aria-label="Close reservation dialog"
            className="p-2 text-[#1E1815]/60 hover:text-[#1E1815] hover:bg-[#F2ECE1] rounded-md transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmationCode ? (
          <div className="py-6">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle2 className="w-7 h-7 text-[#4A5D4E] shrink-0" />
              <div>
                <p className="font-mono text-xs text-[#4A5D4E]">
                  Table Confirmed · Reference {confirmationCode}
                </p>
                <h3 className="font-serif text-2xl font-semibold text-[#1E1815]">
                  We look forward to hosting you, {guestName}.
                </h3>
              </div>
            </div>

            <div className="bg-[#F2ECE1] border border-[#1E1815]/10 rounded-lg p-5 space-y-3 text-sm my-6">
              <div className="flex items-center justify-between gap-4 border-b border-[#1E1815]/10 pb-2.5">
                <span className="text-[#1E1815]/65">Party Size</span>
                <span className="font-mono font-medium tabular-nums">
                  {guests} {guests === 1 ? 'Guest' : 'Guests'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-4 border-b border-[#1E1815]/10 pb-2.5">
                <span className="text-[#1E1815]/65">Date &amp; Seating Window</span>
                <span className="font-mono font-medium tabular-nums text-right">
                  {date} · {timeSlot}
                </span>
              </div>
              <div className="flex items-center justify-between gap-4 border-b border-[#1E1815]/10 pb-2.5">
                <span className="text-[#1E1815]/65">Seating Area</span>
                <span className="font-medium">{seating}</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-[#1E1815]/65">Contact</span>
                <span className="font-mono text-xs">{contact}</span>
              </div>
              {specialRequest.trim() && (
                <div className="pt-2 border-t border-[#1E1815]/10">
                  <span className="text-xs text-[#1E1815]/65 block mb-1">Note to Host</span>
                  <p className="text-xs text-[#1E1815]">{specialRequest}</p>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmationCode(null)}
                className="px-4 py-2.5 text-sm font-medium text-[#1E1815] border border-[#1E1815]/20 hover:border-[#1E1815] rounded-md transition-colors cursor-pointer min-h-[44px]"
              >
                Book Another Table
              </button>
              <button
                type="button"
                onClick={resetAndClose}
                className="px-5 py-2.5 text-sm font-medium text-[#FAF7F2] bg-[#1E1815] hover:bg-[#C85A32] rounded-md transition-colors cursor-pointer min-h-[44px]"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="pt-6 space-y-6" noValidate>
            {/* Guests & Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="flex items-center gap-2 text-xs font-mono text-[#1E1815]/75 mb-2">
                  <Users className="w-3.5 h-3.5 text-[#C85A32]" />
                  <span>Guests (1–8)</span>
                </label>
                <div className="grid grid-cols-8 gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setGuests(num)}
                      className={`py-2 text-xs font-mono tabular-nums rounded border transition-colors cursor-pointer min-h-[40px] ${
                        guests === num
                          ? 'bg-[#1E1815] text-[#FAF7F2] border-[#1E1815]'
                          : 'bg-[#F2ECE1]/60 text-[#1E1815] border-[#1E1815]/15 hover:border-[#1E1815]/45'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label
                  htmlFor="reservation-date"
                  className="flex items-center gap-2 text-xs font-mono text-[#1E1815]/75 mb-2"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#C85A32]" />
                  <span>Preferred Date</span>
                </label>
                <input
                  id="reservation-date"
                  type="date"
                  min={getTodayISODate()}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm font-mono bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] min-h-[40px]"
                  required
                />
              </div>
            </div>

            {/* Time Slot */}
            <div>
              <span className="flex items-center gap-2 text-xs font-mono text-[#1E1815]/75 mb-2">
                <Clock className="w-3.5 h-3.5 text-[#C85A32]" />
                <span>Service Window</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {TIME_SLOTS.map((slot) => {
                  const active = timeSlot === slot.value;
                  return (
                    <button
                      key={slot.value}
                      type="button"
                      onClick={() => setTimeSlot(slot.value)}
                      className={`text-left p-3 rounded-md border transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#1E1815] text-[#FAF7F2] border-[#1E1815]'
                          : 'bg-[#F2ECE1]/60 text-[#1E1815] border-[#1E1815]/15 hover:border-[#1E1815]/45'
                      }`}
                    >
                      <span className="block text-sm font-medium">{slot.label}</span>
                      <span
                        className={`block font-mono text-[11px] mt-0.5 tabular-nums ${
                          active ? 'text-[#D4A359]' : 'text-[#1E1815]/60'
                        }`}
                      >
                        {slot.sub}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Seating Preference */}
            <div>
              <span className="flex items-center gap-2 text-xs font-mono text-[#1E1815]/75 mb-2">
                <MapPin className="w-3.5 h-3.5 text-[#C85A32]" />
                <span>Seating Preference</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {SEATING_OPTIONS.map((opt) => {
                  const active = seating === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setSeating(opt.value)}
                      className={`text-left p-3 rounded-md border transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#4A5D4E] text-[#FAF7F2] border-[#4A5D4E]'
                          : 'bg-[#F2ECE1]/60 text-[#1E1815] border-[#1E1815]/15 hover:border-[#1E1815]/45'
                      }`}
                    >
                      <span className="block text-sm font-medium">{opt.value}</span>
                      <span
                        className={`block text-[11px] mt-0.5 ${
                          active ? 'text-[#FAF7F2]/80' : 'text-[#1E1815]/60'
                        }`}
                      >
                        {opt.note}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Guest Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="guest-name" className="block text-xs font-mono text-[#1E1815]/75 mb-1.5">
                  Full Name
                </label>
                <input
                  id="guest-name"
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="Aarav Mehta"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] min-h-[44px]"
                  required
                />
              </div>
              <div>
                <label htmlFor="guest-contact" className="block text-xs font-mono text-[#1E1815]/75 mb-1.5">
                  Phone or Email
                </label>
                <input
                  id="guest-contact"
                  type="text"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="+91 98200 11223"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] min-h-[44px]"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="guest-notes" className="block text-xs font-mono text-[#1E1815]/75 mb-1.5">
                Occasion or Dietary Note (Optional)
              </label>
              <input
                id="guest-notes"
                type="text"
                value={specialRequest}
                onChange={(e) => setSpecialRequest(e.target.value)}
                placeholder="e.g., Nut allergy at the table, celebrating an anniversary"
                className="w-full px-3.5 py-2.5 text-sm bg-[#F2ECE1]/60 border border-[#1E1815]/18 rounded-md text-[#1E1815] min-h-[44px]"
              />
            </div>

            {error && (
              <p role="alert" className="text-xs font-medium text-[#C85A32]">
                {error}
              </p>
            )}

            <div className="pt-3 border-t border-[#1E1815]/12 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={resetAndClose}
                className="px-4 py-2.5 text-sm font-medium text-[#1E1815]/75 hover:text-[#1E1815] cursor-pointer min-h-[44px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-sm font-medium text-[#FAF7F2] bg-[#C85A32] hover:bg-[#1E1815] rounded-md transition-colors cursor-pointer min-h-[44px]"
              >
                Confirm Reservation
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
