import { useState } from 'react';
import { UtensilsCrossed } from 'lucide-react';

interface EditorialImageProps {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  fallbackTitle?: string;
}

export function EditorialImage({
  src,
  alt,
  className = 'w-full h-full object-cover',
  containerClassName = '',
  fallbackTitle,
}: EditorialImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#F2ECE1] via-[#FAF7F2] to-[#E6DDD0] text-[#1E1815]/70 p-6 text-center ${containerClassName}`}
        role="img"
        aria-label={alt}
      >
        <UtensilsCrossed className="w-7 h-7 text-[#C85A32]/70 mb-2" strokeWidth={1.5} />
        <span className="font-serif text-base font-medium text-[#1E1815]">
          {fallbackTitle || 'Kesar & Crumb'}
        </span>
      </div>
    );
  }

  return (
    <div className={`overflow-hidden bg-[#F2ECE1] ${containerClassName}`}>
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={className}
      />
    </div>
  );
}
