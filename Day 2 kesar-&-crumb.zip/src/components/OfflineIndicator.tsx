import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-4 z-40 flex items-center gap-2.5 rounded-md bg-[#1E1815] border border-[#D4A359]/50 px-3.5 py-2 text-xs font-medium text-[#FAF7F2] shadow-lg"
    >
      <WifiOff className="w-3.5 h-3.5 text-[#D4A359] shrink-0" />
      <span>Offline Mode · Menu &amp; bag saved locally</span>
    </div>
  );
}
