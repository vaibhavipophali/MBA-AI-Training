import { ALCHEMY_IMAGE, ALCHEMY_PRINCIPLES } from '../data/menuData';
import { EditorialImage } from './EditorialImage';

export function AlchemySection() {
  return (
    <section
      id="our-story"
      className="py-16 lg:py-24 bg-[#F2ECE1] border-y border-[#1E1815]/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Editorial Intro Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center mb-14 lg:mb-18">
          <div className="lg:col-span-6">
            <div className="aspect-[4/3] w-full rounded-xl overflow-hidden border border-[#1E1815]/10 shadow-sm">
              <EditorialImage
                src={ALCHEMY_IMAGE}
                alt="Cross-section of laminated croissant dough beside Kashmiri saffron, Chikmagalur coffee beans, palm jaggery, and green cardamom"
                containerClassName="w-full h-full"
                className="w-full h-full object-cover"
                fallbackTitle="The Alchemy of Spice & Butter"
              />
            </div>
          </div>

          <div className="lg:col-span-6">
            <p className="font-mono text-xs text-[#C85A32] tracking-wide mb-3">
              The Alchemy · Craft &amp; Provenance
            </p>
            <h2
              className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#1E1815] tracking-tight leading-[1.08] mb-5"
              style={{ textWrap: 'balance' }}
            >
              Where Parisian Discipline Meets Indian Terroir.
            </h2>
            <p className="text-base text-[#1E1815]/75 leading-relaxed mb-5">
              Kesar &amp; Crumb began with a simple kitchen question: what happens when classical
              French pastry discipline respects the full depth of unrefined Indian botanicals—without
              turning either into novelty?
            </p>
            <p className="text-base text-[#1E1815]/75 leading-relaxed">
              We mill single-origin grains, steep whole spices in small copper vessels rather than
              using extracts, and pair every bake with estate coffees roasted forty-eight hours
              after harvest.
            </p>
          </div>
        </div>

        {/* 3-Column Visual Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-10 border-t border-[#1E1815]/15">
          {ALCHEMY_PRINCIPLES.map((principle) => (
            <div key={principle.number} className="flex flex-col justify-between">
              <div>
                <div className="flex items-baseline justify-between gap-4 pb-3 mb-4 border-b border-[#1E1815]/12">
                  <span className="font-mono text-lg font-medium text-[#C85A32] tabular-nums">
                    {principle.number}.
                  </span>
                  <span className="font-mono text-xs text-[#4A5D4E] text-right">
                    {principle.technique}
                  </span>
                </div>

                <h3 className="font-serif text-2xl font-semibold text-[#1E1815] leading-snug mb-3">
                  {principle.title}
                </h3>

                <p className="text-sm text-[#1E1815]/75 leading-relaxed mb-5">
                  {principle.description}
                </p>
              </div>

              <div className="pt-3 border-t border-[#1E1815]/10 text-xs font-mono text-[#1E1815]/65 flex flex-col gap-1">
                <span>Hero Ingredient: {principle.ingredient}</span>
                <span className="text-[#1E1815]/85">Featured: {principle.featuredDish}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
