import { Calendar, ShoppingBag } from 'lucide-react';
import { HIGH_TEA_FLIGHT_ITEM, HIGH_TEA_IMAGE, MenuItem } from '../data/menuData';
import { EditorialImage } from './EditorialImage';

interface TastingFlightSectionProps {
  onReserveHighTea: () => void;
  onAddFlightToCart: (item: MenuItem) => void;
}

const TIERS = [
  {
    tier: 'Tier I',
    title: 'Savory Kulcha & Chaat',
    detail: 'Mini chilli-truffle kulcha brioche, avocado tamarind tartines, smoked bharta crostini',
  },
  {
    tier: 'Tier II',
    title: 'Warm Viennoiserie',
    detail: 'Petite gulkand pistachio croissants and saffron almond kouign-amann warm from the deck',
  },
  {
    tier: 'Tier III',
    title: 'Petit Gâteaux & Pour Service',
    detail: 'Rasmalai tres leches squares, burnt chai cheesecake, and two stoneware pots of Assam chai',
  },
];

export function TastingFlightSection({
  onReserveHighTea,
  onAddFlightToCart,
}: TastingFlightSectionProps) {
  return (
    <section id="tasting-flight" className="py-16 lg:py-24 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#1E1815] text-[#FAF7F2] rounded-2xl overflow-hidden border border-[#D4A359]/30">
          {/* 16:9 High-Tea Banner */}
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-7 relative min-h-[280px] sm:min-h-[360px] lg:min-h-[460px]">
              <EditorialImage
                src={HIGH_TEA_IMAGE}
                alt="Three-tier Indo-French High Tea stand with saffron tarts, truffle kulcha bites, rose pistachio financiers, and chai pots in a sunlit courtyard"
                containerClassName="w-full h-full"
                className="w-full h-full object-cover"
                fallbackTitle="Indo-French High Tea Flight"
              />
              <div className="hidden lg:block absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-[#1E1815] to-transparent pointer-events-none" />
            </div>

            <div className="lg:col-span-5 p-7 sm:p-10 lg:p-12 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-4 mb-4">
                  <span className="font-mono text-xs text-[#D4A359] tracking-wide">
                    Chef&apos;s Tasting Experience
                  </span>
                  <span className="font-mono text-sm text-[#FAF7F2] tabular-nums">
                    ₹2,400 · For Two
                  </span>
                </div>

                <h2
                  className="font-serif text-3xl sm:text-4xl font-semibold text-[#FAF7F2] tracking-tight leading-tight mb-4"
                  style={{ textWrap: 'balance' }}
                >
                  The Courtyard Indo-French High Tea Flight
                </h2>

                <p className="text-sm sm:text-base text-[#FAF7F2]/80 leading-relaxed mb-7">
                  Served daily from 2:00 PM to 5:30 PM on brushed brass and handmade stoneware.
                  Designed for unhurried afternoons under the frangipani canopy.
                </p>

                {/* Tier Breakdown */}
                <div className="space-y-4 border-t border-[#FAF7F2]/15 pt-5 mb-8">
                  {TIERS.map((entry) => (
                    <div key={entry.tier} className="grid grid-cols-12 gap-3 items-baseline">
                      <span className="col-span-3 font-mono text-xs text-[#D4A359]">
                        {entry.tier}
                      </span>
                      <div className="col-span-9">
                        <p className="text-sm font-medium text-[#FAF7F2]">{entry.title}</p>
                        <p className="text-xs text-[#FAF7F2]/65 leading-relaxed mt-0.5">
                          {entry.detail}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onReserveHighTea}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-[#FAF7F2] bg-[#C85A32] hover:bg-[#D4A359] hover:text-[#1E1815] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[44px]"
                >
                  <Calendar className="w-4 h-4" strokeWidth={1.75} />
                  <span>Reserve High Tea</span>
                </button>

                <button
                  type="button"
                  onClick={() => onAddFlightToCart(HIGH_TEA_FLIGHT_ITEM)}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-[#FAF7F2] border border-[#FAF7F2]/30 hover:border-[#FAF7F2] hover:bg-[#FAF7F2]/10 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[44px]"
                >
                  <ShoppingBag className="w-4 h-4 text-[#D4A359]" strokeWidth={1.75} />
                  <span>Pre-Order Box</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
