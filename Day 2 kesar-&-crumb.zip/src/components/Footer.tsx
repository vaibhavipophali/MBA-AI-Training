import { FormEvent, useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface FooterProps {
  onOpenReserve: () => void;
}

export function Footer({ onOpenReserve }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: FormEvent) => {
    e.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    if (!valid) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer id="visit-us" className="bg-[#1E1815] text-[#FAF7F2] pt-14 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Subtle Geometric Indian Arch Motif Divider */}
        <div className="flex items-center gap-4 mb-12" aria-hidden="true">
          <div className="h-[1px] flex-1 bg-[#D4A359]/25" />
          <svg
            width="44"
            height="22"
            viewBox="0 0 44 22"
            fill="none"
            className="text-[#D4A359] shrink-0"
          >
            <path
              d="M2 20C2 10.5 11 4 22 2C33 4 42 10.5 42 20"
              stroke="currentColor"
              strokeWidth="1.2"
            />
            <path
              d="M10 20C10 13.5 15.5 9 22 7.5C28.5 9 34 13.5 34 20"
              stroke="currentColor"
              strokeWidth="1"
              strokeOpacity="0.6"
            />
            <circle cx="22" cy="14.5" r="1.5" fill="currentColor" />
          </svg>
          <div className="h-[1px] flex-1 bg-[#D4A359]/25" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#FAF7F2]/12">
          {/* Brand & Address */}
          <div className="md:col-span-4">
            <h2 className="font-serif text-3xl font-semibold text-[#FAF7F2] tracking-tight mb-3">
              Kesar &amp; Crumb
            </h2>
            <p className="text-sm text-[#FAF7F2]/75 leading-relaxed mb-5 max-w-xs">
              Modern Indo-French patisserie, laminated viennoiserie, and single-origin espresso
              served in a quiet heritage courtyard.
            </p>
            <div className="text-sm text-[#FAF7F2]/85 space-y-1 mb-5">
              <p>14 Pali Hill Courtyard, Bandra West</p>
              <p>Mumbai, Maharashtra 400050</p>
              <p className="font-mono text-xs text-[#D4A359] pt-1">+91 22 2640 8192</p>
            </div>
            <PWAInstallButton variant="footer" />
          </div>

          {/* Café Hours & Links */}
          <div className="md:col-span-4 grid grid-cols-2 gap-6">
            <div>
              <h3 className="font-mono text-xs text-[#D4A359] tracking-wide mb-3">
                Courtyard Hours
              </h3>
              <ul className="space-y-2 text-sm text-[#FAF7F2]/80">
                <li>
                  <span className="block text-xs text-[#FAF7F2]/55">Tue – Fri</span>
                  <span className="font-mono text-xs tabular-nums">7:00 AM – 9:30 PM</span>
                </li>
                <li>
                  <span className="block text-xs text-[#FAF7F2]/55">Sat – Sun</span>
                  <span className="font-mono text-xs tabular-nums">7:00 AM – 10:30 PM</span>
                </li>
                <li>
                  <span className="block text-xs text-[#FAF7F2]/55">Monday</span>
                  <span className="text-xs text-[#FAF7F2]/65">Closed for Fermentation</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-mono text-xs text-[#D4A359] tracking-wide mb-3">Explore</h3>
              <ul className="space-y-2 text-sm text-[#FAF7F2]/80">
                <li>
                  <a href="#our-story" className="hover:text-[#D4A359] transition-colors">
                    Our Story
                  </a>
                </li>
                <li>
                  <a href="#fusion-menu" className="hover:text-[#D4A359] transition-colors">
                    The Fusion Menu
                  </a>
                </li>
                <li>
                  <a href="#tasting-flight" className="hover:text-[#D4A359] transition-colors">
                    Tasting Flight
                  </a>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={onOpenReserve}
                    className="hover:text-[#D4A359] transition-colors text-left cursor-pointer"
                  >
                    Reserve a Table
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Newsletter Signup */}
          <div className="md:col-span-4">
            <h3 className="font-mono text-xs text-[#D4A359] tracking-wide mb-3">
              Join the Morning Bake List
            </h3>
            <p className="text-sm text-[#FAF7F2]/75 leading-relaxed mb-4">
              Seasonal menu releases, micro-lot Chikmagalur coffee drops, and Sunday pastry box
              pre-orders.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2.5 px-4 py-3 rounded-md bg-[#4A5D4E]/30 border border-[#4A5D4E] text-sm text-[#FAF7F2]">
                <Check className="w-4 h-4 text-[#D4A359] shrink-0" />
                <span>You&apos;re on the Morning Bake List. See you at 7:00 AM.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2" noValidate>
                <div className="flex gap-2">
                  <label htmlFor="newsletter-email" className="sr-only">
                    Email address
                  </label>
                  <input
                    id="newsletter-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="flex-1 min-w-0 px-3.5 py-2.5 text-sm bg-[#FAF7F2]/8 border border-[#FAF7F2]/20 rounded-md text-[#FAF7F2] placeholder:text-[#FAF7F2]/40 focus:border-[#D4A359] min-h-[44px]"
                    required
                  />
                  <button
                    type="submit"
                    aria-label="Subscribe to Morning Bake List"
                    className="inline-flex items-center justify-center px-4 py-2.5 bg-[#C85A32] hover:bg-[#D4A359] hover:text-[#1E1815] text-[#FAF7F2] rounded-md transition-colors cursor-pointer shrink-0 min-h-[44px]"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                {error && (
                  <p role="alert" className="text-xs text-[#D4A359]">
                    {error}
                  </p>
                )}
              </form>
            )}
          </div>
        </div>

        {/* Quiet Copyright Bottom Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#FAF7F2]/55 font-mono">
          <p>© {new Date().getFullYear()} Kesar &amp; Crumb Patisserie. All rights reserved.</p>
          <p>Eggless &amp; Artisanal Lamination Kitchen · Bandra West</p>
        </div>
      </div>
    </footer>
  );
}
