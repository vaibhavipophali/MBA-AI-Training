import { Check, ShoppingBag, X } from 'lucide-react';

interface ToastProps {
  message: string | null;
  onDismiss: () => void;
  onViewCart: () => void;
}

export function Toast({ message, onDismiss, onViewCart }: ToastProps) {
  if (!message) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-5 right-5 z-40 max-w-sm bg-[#1E1815] text-[#FAF7F2] border border-[#D4A359]/40 rounded-lg shadow-xl px-4 py-3 flex items-center gap-3"
    >
      <Check className="w-4 h-4 text-[#D4A359] shrink-0" />
      <p className="text-xs sm:text-sm text-[#FAF7F2] flex-1">{message}</p>
      <button
        type="button"
        onClick={() => {
          onDismiss();
          onViewCart();
        }}
        className="inline-flex items-center gap-1 text-xs font-mono text-[#D4A359] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
      >
        <ShoppingBag className="w-3.5 h-3.5" />
        <span>View Bag</span>
      </button>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Dismiss notification"
        className="p-1 text-[#FAF7F2]/50 hover:text-[#FAF7F2] cursor-pointer"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
