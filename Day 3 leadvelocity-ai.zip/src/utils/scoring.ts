import {
  BantBreakdownItem,
  KpiMetric,
  LeadAnalysis,
  LeadInput,
  PriorityTier,
  SalesRep,
} from '../types/lead';

export const SAMPLE_KPIS: KpiMetric[] = [
  {
    id: 'speed-to-lead',
    label: 'Avg Speed-to-Lead',
    value: '4m 15s',
    delta: '-38% vs last month',
    context: 'Target SLA under 5m',
  },
  {
    id: 'active-leads',
    label: 'Active Inbound Leads',
    value: '18',
    delta: '+6 new today',
    context: 'Across web & demo forms',
  },
  {
    id: 'sql-rate',
    label: 'SQL Conversion Rate',
    value: '34.5%',
    delta: '+4.2% QoQ',
    context: 'Qualified via BANT triage',
  },
];

function extractFirstName(fullName: string): string {
  const trimmed = fullName.trim();
  if (!trimmed) return 'there';
  return trimmed.split(/\s+/)[0];
}

function parseCompanyAndRole(raw: string): { company: string; role: string } {
  const cleaned = raw.trim();
  if (!cleaned) {
    return { company: 'your team', role: 'leader' };
  }

  // Handle patterns like "Role at Company" or "Company - Role" or "Company, Role"
  const atMatch = cleaned.match(/^(.+?)\s+at\s+(.+)$/i);
  if (atMatch) {
    return { role: atMatch[1].trim(), company: atMatch[2].trim() };
  }

  const separatorMatch = cleaned.split(/\s*[—\-|,/]\s*/);
  if (separatorMatch.length >= 2) {
    const first = separatorMatch[0].trim();
    const second = separatorMatch.slice(1).join(' ').trim();
    const roleKeywords = /(vp|vice president|director|head|chief|ceo|cro|cmo|cto|manager|lead|founder|owner)/i;
    if (roleKeywords.test(first) && !roleKeywords.test(second)) {
      return { role: first, company: second };
    }
    return { company: first, role: second };
  }

  return { company: cleaned, role: 'stakeholder' };
}

function getContextFitPoints(input: LeadInput): { points: number; detail: string } {
  let points = 0;
  const reasons: string[] = [];

  const seniorRolePattern = /(vp|vice president|director|head|chief|ceo|cro|cmo|founder|owner|partner|svp|evp|manager)/i;
  if (seniorRolePattern.test(input.companyAndRole)) {
    points += 5;
    reasons.push('Senior buyer title');
  } else if (input.companyAndRole.trim().length >= 4) {
    points += 3;
    reasons.push('Account profile identified');
  }

  if (input.painPoint.trim().length >= 25) {
    points += 5;
    reasons.push('Specific workflow bottleneck');
  } else if (input.painPoint.trim().length >= 8) {
    points += 3;
    reasons.push('Initial pain context');
  }

  return {
    points: Math.min(10, points),
    detail: reasons.length > 0 ? reasons.join(' · ') : 'Baseline inbound record',
  };
}

export function calculateLeadAnalysis(
  input: LeadInput,
  rep: SalesRep,
  options?: { id?: string; analyzedAt?: string; sourceLabel?: string }
): LeadAnalysis {
  const { bant } = input;
  const budgetPoints = bant.budgetApproved ? 25 : 0;
  const authorityPoints = bant.decisionMaker ? 25 : 0;
  const needPoints = bant.clearPainPoint ? 20 : 0;
  const timelinePoints = bant.urgentTimeline ? 20 : 0;
  const contextFit = getContextFitPoints(input);

  const score = Math.min(
    100,
    budgetPoints + authorityPoints + needPoints + timelinePoints + contextFit.points
  );

  let tier: PriorityTier = 'NURTURE';
  let slaWindow = 'Within 24 hours';
  let slaAction = 'Enroll in targeted nurture track and share benchmark guide';
  let nextStepRecommendation =
    'Send tailored educational brief and schedule a low-friction discovery check-in next week.';

  if (score >= 75) {
    tier = 'HOT';
    slaWindow = 'Within 5 minutes';
    slaAction = 'Immediate phone call + WhatsApp + priority calendar link';
    nextStepRecommendation =
      'Call immediately while inbound intent is peak. Propose a 15-minute solution alignment and rollout timeline review today.';
  } else if (score >= 45) {
    tier = 'WARM';
    slaWindow = 'Within 30 minutes';
    slaAction = 'Personalized email + WhatsApp value hook within 30 mins';
    nextStepRecommendation =
      'Address the stated bottleneck directly and confirm missing BANT criteria (budget sign-off or timeline) on a brief discovery call.';
  }

  const breakdown: BantBreakdownItem[] = [
    {
      key: 'budgetApproved',
      label: 'Budget Approved',
      points: budgetPoints,
      maxPoints: 25,
      met: bant.budgetApproved,
      detail: bant.budgetApproved
        ? 'Funding allocated for current cycle'
        : 'Budget confirmation needed in discovery',
    },
    {
      key: 'decisionMaker',
      label: 'Decision Maker Authority',
      points: authorityPoints,
      maxPoints: 25,
      met: bant.decisionMaker,
      detail: bant.decisionMaker
        ? 'Direct buying authority confirmed'
        : 'Identify economic buyer / champion path',
    },
    {
      key: 'clearPainPoint',
      label: 'Clear Pain Point',
      points: needPoints,
      maxPoints: 20,
      met: bant.clearPainPoint,
      detail: bant.clearPainPoint
        ? 'Explicit operational bottleneck verified'
        : 'Quantify business impact during outreach',
    },
    {
      key: 'urgentTimeline',
      label: 'Urgent Timeline (<30 days)',
      points: timelinePoints,
      maxPoints: 20,
      met: bant.urgentTimeline,
      detail: bant.urgentTimeline
        ? 'Active 30-day implementation window'
        : 'Longer-term evaluation horizon',
    },
    {
      key: 'contextFit',
      label: 'Role & Context Fit',
      points: contextFit.points,
      maxPoints: 10,
      met: contextFit.points >= 6,
      detail: contextFit.detail,
    },
  ];

  const firstName = extractFirstName(input.prospectName);
  const { company, role } = parseCompanyAndRole(input.companyAndRole);
  const cleanPain = input.painPoint.trim() || 'slow inbound lead follow-up and qualification bottlenecks';
  const repFirst = extractFirstName(rep.name || 'Sales');
  const repFull = rep.name.trim() || 'Alex Morgan';
  const repEmail = rep.email.trim() || 'alex@leadvelocity.ai';

  const urgencyLine = bant.urgentTimeline
    ? `Since your team is aiming to resolve this within the next 30 days, I put together a quick rollout blueprint so you can see impact in week one.`
    : `I put together a concise 2-minute overview showing how similar teams eliminate manual triage delays without disrupting their current CRM.`;

  const authorityLine = bant.decisionMaker
    ? `Given your role as ${role} at ${company}, would you be open to a focused 15-minute call ${tier === 'HOT' ? 'later today' : 'this week'} to walk through the exact workflow?`
    : `If helpful, I can also share a 1-page ROI brief tailored for your leadership team at ${company} ahead of a quick 15-minute walkthrough.`;

  const emailSubject =
    tier === 'HOT'
      ? `Quick follow-up for ${company}: solving ${cleanPain.slice(0, 48)}${cleanPain.length > 48 ? '...' : ''}`
      : tier === 'WARM'
        ? `${company} inbound workflow — quick idea for ${firstName}`
        : `Benchmark notes for ${company} on inbound lead velocity`;

  const emailBody = `Hi ${firstName},

Thanks for reaching out — I reviewed your note regarding ${cleanPain} at ${company}.

Teams we work with typically run into this exact bottleneck when inbound volume scales faster than manual routing. By automating instant BANT scoring and sub-5-minute rep handoffs, revenue teams typically recover 30%+ of high-intent pipeline that otherwise cools off.

${urgencyLine}

${authorityLine}

Best regards,
${repFull}
${repEmail}`;

  const whatsappPitch =
    tier === 'HOT'
      ? `Hi ${firstName}, this is ${repFirst} from LeadVelocity. Saw your note from ${company} about ${cleanPain}. Since you're targeting a <30-day fix, do you have 10 mins today around 2:30 PM or 4:00 PM to walk through a live setup?`
      : tier === 'WARM'
        ? `Hi ${firstName}, ${repFirst} here. Thanks for connecting from ${company}! Regarding ${cleanPain}, I just sent over a quick 2-min breakdown via email. Open to a brief 15-min chat tomorrow morning to see if it fits your roadmap?`
        : `Hi ${firstName}, ${repFirst} here. Thanks for checking us out at ${company}. Just emailed a short benchmark summary on solving ${cleanPain} whenever you have a spare moment—happy to answer any questions here.`;

  return {
    id: options?.id ?? `lead-${Date.now()}`,
    input: {
      ...input,
      prospectName: input.prospectName.trim(),
      companyAndRole: input.companyAndRole.trim(),
      painPoint: input.painPoint.trim(),
    },
    score,
    tier,
    slaWindow,
    slaAction,
    nextStepRecommendation,
    breakdown,
    emailSubject,
    emailBody,
    whatsappPitch,
    analyzedAt: options?.analyzedAt ?? 'Just now',
    sourceLabel: options?.sourceLabel ?? 'Manual Qualification',
  };
}

export function createSampleRecentLeads(rep: SalesRep): LeadAnalysis[] {
  const sampleInputs: Array<{
    id: string;
    analyzedAt: string;
    sourceLabel: string;
    input: LeadInput;
  }> = [
    {
      id: 'sample-1',
      analyzedAt: '6m ago',
      sourceLabel: 'Demo Request',
      input: {
        prospectName: 'Priya Nair',
        companyAndRole: 'FinStack Global — VP of Revenue Operations',
        painPoint: 'Inbound demo requests wait 4+ hours for SDR routing, causing 40% no-show rate.',
        bant: {
          budgetApproved: true,
          decisionMaker: true,
          clearPainPoint: true,
          urgentTimeline: true,
        },
      },
    },
    {
      id: 'sample-2',
      analyzedAt: '24m ago',
      sourceLabel: 'Pricing Page',
      input: {
        prospectName: 'Marcus Vance',
        companyAndRole: 'Northstar Logistics — Head of Sales',
        painPoint: 'Reps spend too much time chasing unqualified web leads without BANT context.',
        bant: {
          budgetApproved: true,
          decisionMaker: false,
          clearPainPoint: true,
          urgentTimeline: false,
        },
      },
    },
    {
      id: 'sample-3',
      analyzedAt: '1h ago',
      sourceLabel: 'ROI Guide',
      input: {
        prospectName: 'Elena Rostova',
        companyAndRole: 'Veridian Health — Marketing Manager',
        painPoint: 'Exploring ways to align MQL handoff metrics before Q2 planning begins.',
        bant: {
          budgetApproved: false,
          decisionMaker: false,
          clearPainPoint: true,
          urgentTimeline: false,
        },
      },
    },
    {
      id: 'sample-4',
      analyzedAt: '2h ago',
      sourceLabel: 'Inbound Call',
      input: {
        prospectName: 'David Chen',
        companyAndRole: 'Apex Cloud — Chief Commercial Officer',
        painPoint: 'Need immediate sub-5-minute SLA enforcement across 14 regional account executives.',
        bant: {
          budgetApproved: true,
          decisionMaker: true,
          clearPainPoint: true,
          urgentTimeline: false,
        },
      },
    },
  ];

  return sampleInputs.map((item) =>
    calculateLeadAnalysis(item.input, rep, {
      id: item.id,
      analyzedAt: item.analyzedAt,
      sourceLabel: item.sourceLabel,
    })
  );
}
