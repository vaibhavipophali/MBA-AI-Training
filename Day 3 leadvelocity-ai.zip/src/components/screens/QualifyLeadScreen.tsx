import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { BantCriteria, LeadInput } from '../../types/lead';

interface QualifyLeadScreenProps {
  onAnalyzeLead: (input: LeadInput) => void;
  onBackToDashboard: () => void;
}

const BANT_ITEMS: Array<{
  key: keyof BantCriteria;
  label: string;
  helper: string;
  weight: string;
}> = [
  {
    key: 'budgetApproved',
    label: 'Budget Approved',
    helper: 'Confirmed spend allocation or active tool budget for this quarter',
    weight: '+25 pts',
  },
  {
    key: 'decisionMaker',
    label: 'Decision Maker Authority',
    helper: 'Prospect holds sign-off power or direct economic buyer access',
    weight: '+25 pts',
  },
  {
    key: 'clearPainPoint',
    label: 'Clear Pain Point',
    helper: 'Specific inbound bottleneck or revenue leakage clearly articulated',
    weight: '+20 pts',
  },
  {
    key: 'urgentTimeline',
    label: 'Urgent Timeline (<30 days)',
    helper: 'Evaluating solution for rollout within the next 30 days',
    weight: '+20 pts',
  },
];

const SAMPLE_PRESETS: Array<{ label: string; data: LeadInput }> = [
  {
    label: 'Hot Buyer',
    data: {
      prospectName: 'Rachel Kim',
      companyAndRole: 'Veloce SaaS — VP of Sales',
      painPoint:
        'Our 12 SDRs take over 3 hours to respond to pricing page leads, causing qualified pipeline drop-off.',
      bant: {
        budgetApproved: true,
        decisionMaker: true,
        clearPainPoint: true,
        urgentTimeline: true,
      },
    },
  },
  {
    label: 'Warm Prospect',
    data: {
      prospectName: 'Liam O’Connor',
      companyAndRole: 'BrightPath B2B — Revenue Operations Manager',
      painPoint:
        'Lead scoring in our CRM is outdated and reps struggle to prioritize inbound demo requests.',
      bant: {
        budgetApproved: true,
        decisionMaker: false,
        clearPainPoint: true,
        urgentTimeline: false,
      },
    },
  },
  {
    label: 'Early Nurture',
    data: {
      prospectName: 'Sofia Alvarez',
      companyAndRole: 'Kinetix Labs — Growth Marketing Specialist',
      painPoint:
        'Researching speed-to-lead benchmarks ahead of next year’s demand generation planning.',
      bant: {
        budgetApproved: false,
        decisionMaker: false,
        clearPainPoint: true,
        urgentTimeline: false,
      },
    },
  },
];

export function QualifyLeadScreen({
  onAnalyzeLead,
  onBackToDashboard,
}: QualifyLeadScreenProps) {
  const [prospectName, setProspectName] = useState('');
  const [companyAndRole, setCompanyAndRole] = useState('');
  const [painPoint, setPainPoint] = useState('');
  const [bant, setBant] = useState<BantCriteria>({
    budgetApproved: false,
    decisionMaker: false,
    clearPainPoint: true,
    urgentTimeline: false,
  });
  const [error, setError] = useState<string | null>(null);

  const toggleBant = (key: keyof BantCriteria) => {
    setBant((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const applyPreset = (preset: LeadInput) => {
    setProspectName(preset.prospectName);
    setCompanyAndRole(preset.companyAndRole);
    setPainPoint(preset.painPoint);
    setBant(preset.bant);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!prospectName.trim()) {
      setError('Please enter the Prospect Name.');
      return;
    }
    if (!companyAndRole.trim()) {
      setError('Please enter the prospect’s Company & Role.');
      return;
    }
    if (!painPoint.trim()) {
      setError('Please enter the Stated Pain Point to tailor the outreach pitch.');
      return;
    }

    setError(null);
    onAnalyzeLead({
      prospectName: prospectName.trim(),
      companyAndRole: companyAndRole.trim(),
      painPoint: painPoint.trim(),
      bant,
    });
  };

  const checkedCount = Object.values(bant).filter(Boolean).length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-24 md:pb-12">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <button
            type="button"
            onClick={onBackToDashboard}
            className="min-h-[40px] inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-blue-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            <span>Back to Dashboard</span>
          </button>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Qualify Inbound Lead
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Capture prospect context and BANT signals to calculate priority score and generate tailored outreach.
          </p>
        </div>

        {/* Quick-Fill Test Presets */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-500 mr-1">Quick fill:</span>
          {SAMPLE_PRESETS.map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => applyPreset(preset.data)}
              className="min-h-[36px] px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Prospect Details */}
          <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
            <div>
              <h2 className="text-base font-bold text-slate-900">01. Prospect Profile</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Used to personalize subject lines, SLA urgency, and role-relevant hooks.
              </p>
            </div>

            <div>
              <label
                htmlFor="prospect-name"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Prospect Name
              </label>
              <input
                id="prospect-name"
                name="prospectName"
                type="text"
                value={prospectName}
                onChange={(e) => {
                  setProspectName(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="e.g. Rachel Kim"
                className="w-full min-h-[46px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-700 transition-colors"
              />
            </div>

            <div>
              <label
                htmlFor="company-role"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Company &amp; Role
              </label>
              <input
                id="company-role"
                name="companyAndRole"
                type="text"
                value={companyAndRole}
                onChange={(e) => {
                  setCompanyAndRole(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="e.g. Veloce SaaS — VP of Sales"
                className="w-full min-h-[46px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-700 transition-colors"
              />
            </div>

            <div>
              <label
                htmlFor="pain-point"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Stated Pain Point
              </label>
              <textarea
                id="pain-point"
                name="painPoint"
                rows={4}
                value={painPoint}
                onChange={(e) => {
                  setPainPoint(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Describe the inbound challenge or bottleneck the prospect mentioned..."
                className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-700 transition-colors resize-y"
              />
            </div>
          </div>

          {/* Right Column: 4 BANT Checkboxes & Analyze Action */}
          <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">02. BANT Qualification Signals</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Select all verified buying criteria from the inbound submission or call notes.
                </p>
              </div>
              <span className="text-xs font-mono font-semibold text-blue-700 tabular-nums whitespace-nowrap shrink-0">
                {checkedCount} / 4 selected
              </span>
            </div>

            <div className="space-y-3" role="group" aria-label="BANT qualification criteria">
              {BANT_ITEMS.map((item) => {
                const isChecked = bant[item.key];
                return (
                  <label
                    key={item.key}
                    htmlFor={`bant-${item.key}`}
                    className={`min-h-[56px] flex items-start gap-3.5 p-3.5 rounded-xl border transition-colors cursor-pointer select-none ${
                      isChecked
                        ? 'bg-blue-50/70 border-blue-300'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      id={`bant-${item.key}`}
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleBant(item.key)}
                      className="sr-only"
                    />
                    <span
                      aria-hidden="true"
                      className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                        isChecked
                          ? 'bg-blue-700 border-blue-700 text-white'
                          : 'bg-white border-slate-300 text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" strokeWidth={2.75} />
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-slate-900">
                          {item.label}
                        </span>
                        <span className="text-xs font-mono text-slate-500 tabular-nums shrink-0">
                          {item.weight}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-slate-600 leading-relaxed">
                        {item.helper}
                      </p>
                    </div>
                  </label>
                );
              })}
            </div>

            {error && (
              <div
                role="alert"
                className="px-3.5 py-2.5 text-xs sm:text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl"
              >
                {error}
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                className="w-full min-h-[48px] px-5 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 active:scale-[0.99] rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
              >
                <span>Analyze Lead &amp; Generate Pitch</span>
                <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
