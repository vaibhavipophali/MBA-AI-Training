import React, { useState } from 'react';
import { ArrowRight, Zap, ShieldCheck, Clock } from 'lucide-react';
import { SalesRep } from '../../types/lead';
import { PWAInstallButton } from '../PWAInstallButton';
import { PWAInstallButton } from '../PWAInstallButton';

interface WelcomeScreenProps {
  initialRep: SalesRep;
  onEnterWorkspace: (rep: SalesRep) => void;
}

export function WelcomeScreen({ initialRep, onEnterWorkspace }: WelcomeScreenProps) {
  const [name, setName] = useState(initialRep.name);
  const [email, setEmail] = useState(initialRep.email);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName) {
      setError('Please enter your Sales Rep Name to personalize your workspace.');
      return;
    }

    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Please enter a valid Work Email address.');
      return;
    }

    setError(null);
    onEnterWorkspace({ name: trimmedName, email: trimmedEmail });
  };

  const handleUseDemoRep = () => {
    const demoRep = { name: 'Jordan Mercer', email: 'j.mercer@acmerevenue.com' };
    setName(demoRep.name);
    setEmail(demoRep.email);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl w-full mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Left Column: Corporate Value Summary */}
          <div className="lg:col-span-6 flex flex-col justify-between bg-blue-900 text-white rounded-2xl p-6 sm:p-8 lg:p-10">
            <div>
              <div className="flex items-center gap-2.5 text-blue-200 text-xs font-medium tracking-wide">
                <Zap className="w-4 h-4 text-blue-300" aria-hidden="true" />
                <span>Marketing &amp; Sales Acceleration</span>
              </div>

              <h1 className="mt-5 text-3xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
                LeadVelocity AI
              </h1>
              <p className="mt-3 text-base sm:text-lg text-blue-100 leading-relaxed [text-wrap:balance]">
                Inbound Lead Triage &amp; Speed-to-Lead Co-Pilot
              </p>

              <p className="mt-6 text-sm text-blue-100/90 leading-relaxed max-w-md">
                Eliminate inbound follow-up bottlenecks. Score BANT readiness in seconds, assign strict SLA response windows, and launch tailored multi-channel outreach before competitor reps dial.
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-blue-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-blue-300 mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold text-white tabular-nums">&lt; 5 Min SLA Triage</p>
                  <p className="text-xs text-blue-200 mt-0.5">Instant HOT, WARM, or NURTURE routing</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-blue-300 mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold text-white">Structured BANT Scoring</p>
                  <p className="text-xs text-blue-200 mt-0.5">Tailored Email &amp; WhatsApp drafts</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Rep Sign-In Card */}
          <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 lg:p-10 flex flex-col justify-center">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                  Sales Rep Sign In
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Enter your details to personalize outreach signatures and KPIs.
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-5" noValidate>
              <div>
                <label
                  htmlFor="rep-name"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Sales Rep Name
                </label>
                <input
                  id="rep-name"
                  name="repName"
                  type="text"
                  autoComplete="name"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="e.g. Jordan Mercer"
                  className="w-full min-h-[46px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-700 transition-colors"
                />
              </div>

              <div>
                <label
                  htmlFor="rep-email"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Work Email
                </label>
                <input
                  id="rep-email"
                  name="repEmail"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="e.g. j.mercer@company.com"
                  className="w-full min-h-[46px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-700 transition-colors"
                />
              </div>

              {error && (
                <div
                  role="alert"
                  className="px-3.5 py-2.5 text-xs sm:text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl"
                >
                  {error}
                </div>
              )}

              <div className="pt-1 space-y-3">
                <button
                  type="submit"
                  className="w-full min-h-[48px] px-5 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 active:scale-[0.99] rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
                >
                  <span>Enter Sales Workspace</span>
                  <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                </button>

                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pt-1">
                  <PWAInstallButton variant="subtle" />
                  <button
                    type="button"
                    onClick={handleUseDemoRep}
                    className="font-medium text-blue-700 hover:text-blue-800 underline underline-offset-4 cursor-pointer min-h-[36px] px-1"
                  >
                    Fill demo rep details
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
