import { useState } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  Clock,
  Mail,
  MessageSquare,
  Plus,
  CheckCircle2,
  Circle,
} from 'lucide-react';
import { LeadAnalysis } from '../../types/lead';
import { PriorityTierBadge } from '../PriorityTierBadge';

interface ResultsScreenProps {
  analysis: LeadAnalysis;
  onBackToDashboard: () => void;
  onQualifyAnother: () => void;
}

type OutreachChannel = 'email' | 'whatsapp';

export function ResultsScreen({
  analysis,
  onBackToDashboard,
  onQualifyAnother,
}: ResultsScreenProps) {
  const [channel, setChannel] = useState<OutreachChannel>('email');
  const [copied, setCopied] = useState(false);

  const activeMessage =
    channel === 'email'
      ? `Subject: ${analysis.emailSubject}\n\n${analysis.emailBody}`
      : analysis.whatsappPitch;

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(activeMessage);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      // Fallback copy method if Clipboard API is restricted
      const textarea = document.createElement('textarea');
      textarea.value = activeMessage;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2200);
      } finally {
        document.body.removeChild(textarea);
      }
    }
  };

  // SVG Ring math
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (analysis.score / 100) * circumference;

  const ringStrokeClass =
    analysis.tier === 'HOT'
      ? 'stroke-red-600'
      : analysis.tier === 'WARM'
        ? 'stroke-amber-500'
        : 'stroke-blue-700';

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-24 md:pb-12 space-y-6">
      {/* Top Action Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              {analysis.input.prospectName}
            </h1>
            <PriorityTierBadge tier={analysis.tier} size="md" />
          </div>
          <p className="mt-1 text-sm text-slate-600">
            {analysis.input.companyAndRole} <span aria-hidden="true">·</span> {analysis.sourceLabel}{' '}
            <span aria-hidden="true">·</span> {analysis.analyzedAt}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onQualifyAnother}
            className="min-h-[44px] px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>New Lead</span>
          </button>

          <button
            type="button"
            onClick={onBackToDashboard}
            className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            <span>Back to Dashboard</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Results Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: BANT Score, SLA Window & Signal Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          {/* Score & SLA Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6">
            <div className="flex items-center gap-5">
              {/* SVG Circular Score Gauge */}
              <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                <svg className="w-28 h-28 -rotate-90" viewBox="0 0 104 104" aria-hidden="true">
                  <circle
                    cx="52"
                    cy="52"
                    r={radius}
                    fill="none"
                    strokeWidth="9"
                    className="stroke-slate-100"
                  />
                  <circle
                    cx="52"
                    cy="52"
                    r={radius}
                    fill="none"
                    strokeWidth="9"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    className={`${ringStrokeClass} transition-all duration-300`}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-2xl font-bold text-slate-900 font-mono tabular-nums leading-none">
                    {analysis.score}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500 mt-1">/ 100</span>
                </div>
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-slate-500">BANT Priority Score</p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-lg font-bold text-slate-900">
                    {analysis.tier} Priority
                  </span>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-blue-700 shrink-0" aria-hidden="true" />
                    <span>Recommended SLA Window</span>
                  </div>
                  <p className="mt-0.5 text-sm sm:text-base font-bold text-blue-800 font-mono tabular-nums">
                    {analysis.slaWindow}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-100">
              <p className="text-xs font-semibold text-slate-800">Recommended Action</p>
              <p className="mt-1 text-sm text-slate-600 leading-relaxed">
                {analysis.nextStepRecommendation}
              </p>
            </div>
          </div>

          {/* BANT Signal Breakdown */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6">
            <h2 className="text-base font-bold text-slate-900">BANT Score Breakdown</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Transparent qualification weighting from 0 to 100 points.
            </p>

            <ul className="mt-4 divide-y divide-slate-100">
              {analysis.breakdown.map((item) => (
                <li key={item.key} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5 min-w-0">
                    {item.met ? (
                      <CheckCircle2
                        className="w-4 h-4 text-blue-700 mt-0.5 shrink-0"
                        aria-hidden="true"
                      />
                    ) : (
                      <Circle
                        className="w-4 h-4 text-slate-300 mt-0.5 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900">{item.label}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{item.detail}</p>
                    </div>
                  </div>
                  <span
                    className={`text-xs font-mono font-semibold tabular-nums shrink-0 ${
                      item.points > 0 ? 'text-blue-700' : 'text-slate-400'
                    }`}
                  >
                    +{item.points}/{item.maxPoints}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right Column: Personalized Email & WhatsApp Pitch */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 flex flex-col">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Personalized Outreach Pitch
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Tailored to {analysis.input.prospectName}’s pain point and BANT readiness.
              </p>
            </div>

            {/* Channel Switcher */}
            <div
              role="tablist"
              aria-label="Outreach channel"
              className="inline-flex items-center p-1 bg-slate-100 rounded-xl self-start sm:self-auto"
            >
              <button
                type="button"
                role="tab"
                aria-selected={channel === 'email'}
                onClick={() => {
                  setChannel('email');
                  setCopied(false);
                }}
                className={`min-h-[38px] px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
                  channel === 'email'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Mail className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Follow-up Email</span>
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={channel === 'whatsapp'}
                onClick={() => {
                  setChannel('whatsapp');
                  setCopied(false);
                }}
                className={`min-h-[38px] px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
                  channel === 'whatsapp'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" aria-hidden="true" />
                <span>WhatsApp Pitch</span>
              </button>
            </div>
          </div>

          {/* Stated Pain Point Reference */}
          <div className="mt-4 px-4 py-3 bg-slate-50 border border-slate-200/80 rounded-xl">
            <p className="text-xs font-medium text-slate-500">Captured Pain Point</p>
            <p className="mt-0.5 text-sm text-slate-800">{analysis.input.painPoint}</p>
          </div>

          {/* Pitch Content */}
          <div className="mt-4 flex-1">
            {channel === 'email' ? (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
                  <span className="text-xs font-medium text-slate-500">Subject: </span>
                  <span className="text-sm font-semibold text-slate-900">
                    {analysis.emailSubject}
                  </span>
                </div>
                <div className="p-4 sm:p-5 bg-white">
                  <pre className="whitespace-pre-wrap font-sans text-sm text-slate-800 leading-relaxed">
                    {analysis.emailBody}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500">
                    WhatsApp Direct Message
                  </span>
                  <span className="text-xs font-mono text-slate-500 tabular-nums">
                    {analysis.whatsappPitch.length} chars
                  </span>
                </div>
                <div className="p-4 sm:p-5 bg-white">
                  <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">
                    {analysis.whatsappPitch}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Primary Copy & Back Actions */}
          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              type="button"
              onClick={handleCopyMessage}
              className="flex-1 min-h-[48px] px-5 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 active:scale-[0.99] rounded-xl transition-all inline-flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Copied Outreach Message</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Copy Outreach Message</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onBackToDashboard}
              className="min-h-[48px] px-5 py-3 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Back to Dashboard</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
