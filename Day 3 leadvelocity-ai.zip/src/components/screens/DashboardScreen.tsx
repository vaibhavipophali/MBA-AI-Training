import { useMemo, useState } from 'react';
import { Plus, ChevronRight, Search } from 'lucide-react';
import { KpiMetric, LeadAnalysis, PriorityTier, SalesRep } from '../../types/lead';
import { PriorityTierBadge } from '../PriorityTierBadge';
import { PWAInstallButton } from '../PWAInstallButton';
import { PWAInstallButton } from '../PWAInstallButton';

interface DashboardScreenProps {
  rep: SalesRep;
  kpis: KpiMetric[];
  leads: LeadAnalysis[];
  onStartQualify: () => void;
  onSelectLead: (lead: LeadAnalysis) => void;
}

export function DashboardScreen({
  rep,
  kpis,
  leads,
  onStartQualify,
  onSelectLead,
}: DashboardScreenProps) {
  const [tierFilter, setTierFilter] = useState<'ALL' | PriorityTier>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const firstName = rep.name.trim().split(/\s+/)[0] || 'Rep';

  const filteredLeads = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return leads.filter((lead) => {
      const matchesTier = tierFilter === 'ALL' || lead.tier === tierFilter;
      const matchesSearch =
        !query ||
        lead.input.prospectName.toLowerCase().includes(query) ||
        lead.input.companyAndRole.toLowerCase().includes(query) ||
        lead.input.painPoint.toLowerCase().includes(query);
      return matchesTier && matchesSearch;
    });
  }, [leads, tierFilter, searchQuery]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-24 md:pb-12 space-y-8">
      {/* Greeting & Primary Action Header */}
      <section className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Sales Workspace <span aria-hidden="true">·</span> {rep.email}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Welcome back, {firstName}
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Monitor inbound response speed and triage incoming prospects by BANT priority.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
          <PWAInstallButton variant="secondary" />
          <button
            type="button"
            onClick={onStartQualify}
            className="w-full sm:w-auto min-h-[48px] px-5 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 active:scale-[0.99] rounded-xl transition-all inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
          >
            <Plus className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Qualify New Inbound Lead</span>
          </button>
        </div>
      </section>

      {/* Marketing & Sales KPI Cards (Sample Data) */}
      <section aria-labelledby="kpi-section-heading">
        <div className="flex items-center justify-between gap-4 mb-3">
          <h2 id="kpi-section-heading" className="text-sm font-semibold text-slate-900">
            Marketing &amp; Sales Performance
          </h2>
          <span className="text-xs font-medium text-slate-500">
            Sample Data <span aria-hidden="true">·</span> Last 30 days
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {kpis.map((kpi) => (
            <div
              key={kpi.id}
              className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-slate-500">{kpi.label}</span>
                <span className="text-[11px] font-medium text-slate-400">Sample Data</span>
              </div>

              <div className="mt-3 flex items-baseline justify-between gap-3">
                <span className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono tabular-nums tracking-tight">
                  {kpi.value}
                </span>
                <span className="text-xs font-medium text-blue-700 tabular-nums">
                  {kpi.delta}
                </span>
              </div>

              <p className="mt-2 pt-2.5 border-t border-slate-100 text-xs text-slate-500">
                {kpi.context}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Recent Inbound Leads Queue */}
      <section aria-labelledby="recent-leads-heading" className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 id="recent-leads-heading" className="text-base sm:text-lg font-bold text-slate-900">
              Recent Inbound Leads
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Select any lead to inspect its BANT Priority Score, SLA window, and outreach pitch.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter prospect or company..."
                aria-label="Filter recent leads"
                className="w-full sm:w-56 min-h-[40px] pl-9 pr-3 py-1.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-lg placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-blue-600 transition-colors"
              />
            </div>

            {/* Tier Filter Segmented Control */}
            <div
              role="group"
              aria-label="Filter by priority tier"
              className="inline-flex items-center p-1 bg-slate-100 rounded-lg overflow-x-auto"
            >
              {(['ALL', 'HOT', 'WARM', 'NURTURE'] as const).map((tier) => {
                const active = tierFilter === tier;
                return (
                  <button
                    key={tier}
                    type="button"
                    onClick={() => setTierFilter(tier)}
                    className={`min-h-[34px] px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      active
                        ? 'bg-white text-blue-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tier === 'ALL' ? 'All' : tier}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {filteredLeads.length === 0 ? (
          <div className="p-8 sm:p-12 text-center">
            <p className="text-sm font-medium text-slate-800">No leads match your current filter.</p>
            <p className="mt-1 text-xs text-slate-500">
              Clear the search filter or qualify a new inbound lead to add it here.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setTierFilter('ALL');
                  setSearchQuery('');
                }}
                className="min-h-[40px] px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Reset Filters
              </button>
              <button
                type="button"
                onClick={onStartQualify}
                className="min-h-[40px] px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
              >
                + Qualify Lead
              </button>
            </div>
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {filteredLeads.map((lead) => (
              <li key={lead.id}>
                <button
                  type="button"
                  onClick={() => onSelectLead(lead)}
                  className="w-full text-left px-4 sm:px-6 py-4 hover:bg-slate-50/90 active:bg-slate-100/80 transition-colors flex items-center justify-between gap-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-blue-600"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                      <span className="text-sm sm:text-base font-semibold text-slate-900 truncate">
                        {lead.input.prospectName}
                      </span>
                      <PriorityTierBadge tier={lead.tier} size="sm" />
                      <span className="text-xs font-mono font-semibold text-blue-700 tabular-nums">
                        {lead.score}/100
                      </span>
                    </div>

                    <p className="mt-1 text-xs sm:text-sm text-slate-700 truncate">
                      {lead.input.companyAndRole}
                    </p>

                    <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                      <span>{lead.sourceLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>SLA: {lead.slaWindow}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{lead.analyzedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="hidden sm:inline text-xs font-medium text-blue-700">
                      View Report
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400" aria-hidden="true" />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
