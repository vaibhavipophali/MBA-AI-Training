import { Flame, Clock, Sprout } from 'lucide-react';
import { PriorityTier } from '../types/lead';

interface PriorityTierBadgeProps {
  tier: PriorityTier;
  size?: 'sm' | 'md';
}

export function PriorityTierBadge({ tier, size = 'md' }: PriorityTierBadgeProps) {
  const config: Record<
    PriorityTier,
    {
      label: string;
      classes: string;
      Icon: typeof Flame;
    }
  > = {
    HOT: {
      label: 'HOT',
      classes: 'bg-red-50 text-red-700 border-red-200',
      Icon: Flame,
    },
    WARM: {
      label: 'WARM',
      classes: 'bg-amber-50 text-amber-800 border-amber-200',
      Icon: Clock,
    },
    NURTURE: {
      label: 'NURTURE',
      classes: 'bg-blue-50 text-blue-700 border-blue-200',
      Icon: Sprout,
    },
  };

  const { label, classes, Icon } = config[tier];

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono font-semibold tracking-wide border whitespace-nowrap shrink-0 ${classes} ${
        size === 'sm' ? 'px-2 py-0.5 text-[11px] rounded' : 'px-3 py-1 text-xs rounded-md'
      }`}
    >
      <Icon className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} aria-hidden="true" />
      <span>{label}</span>
    </span>
  );
}
