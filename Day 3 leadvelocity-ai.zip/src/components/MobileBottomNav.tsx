import { LayoutDashboard, ClipboardCheck, FileBarChart2, LogIn } from 'lucide-react';
import { ScreenId } from '../types/lead';

interface MobileBottomNavProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

const MOBILE_TABS: Array<{
  id: ScreenId;
  label: string;
  Icon: typeof LayoutDashboard;
}> = [
  { id: 'welcome', label: 'Login', Icon: LogIn },
  { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { id: 'qualify', label: 'Qualify', Icon: ClipboardCheck },
  { id: 'results', label: 'Results', Icon: FileBarChart2 },
];

export function MobileBottomNav({ activeScreen, onNavigate }: MobileBottomNavProps) {
  return (
    <nav
      aria-label="Mobile screen navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200"
    >
      <div className="grid grid-cols-4 h-[60px] items-center px-1">
        {MOBILE_TABS.map(({ id, label, Icon }) => {
          const isActive = activeScreen === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600 ${
                isActive ? 'text-blue-700' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="w-5 h-5" strokeWidth={isActive ? 2.25 : 1.75} aria-hidden="true" />
              <span className="text-[11px] font-medium leading-none whitespace-nowrap">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
