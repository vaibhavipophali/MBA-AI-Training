import { useState } from 'react';
import { Download, X, Share, Monitor, Smartphone, Check, Copy } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

const SHARED_APP_URL =
  'https://ais-pre-jn5ftcyumvj6pfzaiu4fm3-794562168527.asia-east1.run.app';

interface PWAInstallButtonProps {
  variant?: 'secondary' | 'subtle';
}

export function PWAInstallButton({ variant = 'secondary' }: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(SHARED_APP_URL);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = SHARED_APP_URL;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        setCopiedUrl(true);
        window.setTimeout(() => setCopiedUrl(false), 2000);
      } finally {
        document.body.removeChild(textarea);
      }
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={
          variant === 'subtle'
            ? 'min-h-[40px] px-3 py-1.5 text-xs font-medium text-blue-700 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer'
            : 'min-h-[44px] px-4 py-2 text-xs sm:text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer'
        }
      >
        <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
        <span>Install App</span>
      </button>

      {showGuide && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 shadow-xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 id="pwa-install-title" className="text-lg font-bold text-slate-900">
                  Install LeadVelocity AI
                </h3>
                <p className="mt-1 text-xs sm:text-sm text-slate-600">
                  Add this app directly to your phone home screen or laptop desktop.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install instructions"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <p className="text-xs font-medium text-slate-500">Direct App Link</p>
              <div className="mt-1.5 flex items-center gap-2">
                <code className="flex-1 text-xs font-mono text-slate-800 truncate">
                  {SHARED_APP_URL}
                </code>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="min-h-[36px] px-2.5 py-1 text-xs font-semibold text-blue-700 bg-white border border-slate-200 hover:bg-blue-50 rounded-lg inline-flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="mt-4 space-y-3 text-xs sm:text-sm text-slate-700">
              {isIOS ? (
                <div className="p-3.5 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="flex items-center gap-2 font-semibold text-slate-900">
                    <Share className="w-4 h-4 text-blue-700" aria-hidden="true" />
                    <span>iPhone &amp; iPad (Safari)</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    1. Open the direct link in <strong>Safari</strong>.<br />
                    2. Tap the <strong>Share</strong> button in the bottom toolbar.<br />
                    3. Scroll down and tap <strong>Add to Home Screen</strong>.
                  </p>
                </div>
              ) : (
                <>
                  <div className="p-3.5 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 font-semibold text-slate-900">
                      <Smartphone className="w-4 h-4 text-blue-700" aria-hidden="true" />
                      <span>Mobile (Android Chrome / iOS Safari)</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">
                      Open the link above in Chrome (tap <strong>Install app</strong> / <strong>Add to Home screen</strong> in menu) or Safari (<strong>Share → Add to Home Screen</strong>).
                    </p>
                  </div>
                  <div className="p-3.5 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 font-semibold text-slate-900">
                      <Monitor className="w-4 h-4 text-blue-700" aria-hidden="true" />
                      <span>Laptop / Desktop (Chrome or Edge)</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">
                      Open the link in a browser tab and click the <strong>Install</strong> icon in the address bar (or browser menu → <strong>Install LeadVelocity AI</strong>).
                    </p>
                  </div>
                </>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 w-full min-h-[44px] py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </>
  );
}
