import { ScreenId } from '../types/lead';

interface TopNavProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  repName: string;
}

const NAV_ITEMS: Array<{ id: ScreenId; label: string }> = [
  { id: 'welcome', label: 'Welcome' },
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'qualify', label: 'Qualify Lead' },
  { id: 'results', label: 'Results' },
];

export function TopNav({ activeScreen, onNavigate, repName }: TopNavProps) {
  return (
    <header className="bg-white border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('dashboard')}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 rounded"
        >
          LeadVelocity <span className="text-blue-700">AI</span>
        </button>

        {/* Zone 2: 4 single-line navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
          {NAV_ITEMS.map((item) => {
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`py-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 ${
                  isActive
                    ? 'text-blue-700 border-blue-700'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {activeScreen === 'qualify' ? (
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="min-h-[40px] px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
            >
              Dashboard
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('qualify')}
              className="min-h-[40px] px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
            >
              + Qualify Lead
            </button>
          )}
          <span className="sr-only">Signed in as {repName || 'Sales Rep'}</span>
        </div>
      </div>
    </header>
  );
}
