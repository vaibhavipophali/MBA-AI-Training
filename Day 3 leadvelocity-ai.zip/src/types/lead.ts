export type ScreenId = 'welcome' | 'dashboard' | 'qualify' | 'results';

export type PriorityTier = 'HOT' | 'WARM' | 'NURTURE';

export interface SalesRep {
  name: string;
  email: string;
}

export interface BantCriteria {
  budgetApproved: boolean;
  decisionMaker: boolean;
  clearPainPoint: boolean;
  urgentTimeline: boolean;
}

export interface LeadInput {
  prospectName: string;
  companyAndRole: string;
  painPoint: string;
  bant: BantCriteria;
}

export interface BantBreakdownItem {
  key: keyof BantCriteria | 'contextFit';
  label: string;
  points: number;
  maxPoints: number;
  met: boolean;
  detail: string;
}

export interface LeadAnalysis {
  id: string;
  input: LeadInput;
  score: number;
  tier: PriorityTier;
  slaWindow: string;
  slaAction: string;
  nextStepRecommendation: string;
  breakdown: BantBreakdownItem[];
  emailSubject: string;
  emailBody: string;
  whatsappPitch: string;
  analyzedAt: string;
  sourceLabel: string;
}

export interface KpiMetric {
  id: string;
  label: string;
  value: string;
  delta: string;
  context: string;
}
