import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { LeadAnalysis, LeadInput, SalesRep, ScreenId } from './types/lead';
import {
  SAMPLE_KPIS,
  calculateLeadAnalysis,
  createSampleRecentLeads,
} from './utils/scoring';
import { TopNav } from './components/TopNav';
import { MobileBottomNav } from './components/MobileBottomNav';
import { OfflineIndicator } from './components/OfflineIndicator';
import { WelcomeScreen } from './components/screens/WelcomeScreen';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { QualifyLeadScreen } from './components/screens/QualifyLeadScreen';
import { ResultsScreen } from './components/screens/ResultsScreen';

const DEFAULT_REP: SalesRep = {
  name: '',
  email: '',
};

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('welcome');
  const [rep, setRep] = useState<SalesRep>(DEFAULT_REP);
  const [leads, setLeads] = useState<LeadAnalysis[]>(() =>
    createSampleRecentLeads({ name: 'Jordan Mercer', email: 'j.mercer@acmerevenue.com' })
  );
  const [selectedLeadId, setSelectedLeadId] = useState<string>('sample-1');

  const handleEnterWorkspace = (enteredRep: SalesRep) => {
    setRep(enteredRep);
    // Keep custom qualified leads and refresh sample lead signatures with the active rep
    setLeads((prevLeads) => {
      const customLeads = prevLeads
        .filter((l) => !l.id.startsWith('sample-'))
        .map((l) =>
          calculateLeadAnalysis(l.input, enteredRep, {
            id: l.id,
            analyzedAt: l.analyzedAt,
            sourceLabel: l.sourceLabel,
          })
        );
      const refreshedSamples = createSampleRecentLeads(enteredRep);
      return [...customLeads, ...refreshedSamples];
    });
    setActiveScreen('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (screen: ScreenId) => {
    // Ensure a fallback rep name if navigating directly from header/nav
    if (screen !== 'welcome' && !rep.name.trim()) {
      setRep({ name: 'Jordan Mercer', email: 'j.mercer@acmerevenue.com' });
    }
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectLead = (lead: LeadAnalysis) => {
    setSelectedLeadId(lead.id);
    setActiveScreen('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAnalyzeLead = (input: LeadInput) => {
    const activeRep: SalesRep = rep.name.trim()
      ? rep
      : { name: 'Jordan Mercer', email: 'j.mercer@acmerevenue.com' };

    const analysis = calculateLeadAnalysis(input, activeRep, {
      id: `lead-${Date.now()}`,
      analyzedAt: 'Just now',
      sourceLabel: 'Inbound Qualification',
    });

    setLeads((prev) => [analysis, ...prev]);
    setSelectedLeadId(analysis.id);
    setActiveScreen('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeAnalysis = leads.find((l) => l.id === selectedLeadId) ?? leads[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {activeScreen !== 'welcome' && (
        <TopNav
          activeScreen={activeScreen}
          onNavigate={handleNavigate}
          repName={rep.name || 'Sales Rep'}
        />
      )}

      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeScreen}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeScreen === 'welcome' && (
              <WelcomeScreen
                initialRep={rep}
                onEnterWorkspace={handleEnterWorkspace}
              />
            )}

            {activeScreen === 'dashboard' && (
              <DashboardScreen
                rep={rep}
                kpis={SAMPLE_KPIS}
                leads={leads}
                onStartQualify={() => handleNavigate('qualify')}
                onSelectLead={handleSelectLead}
              />
            )}

            {activeScreen === 'qualify' && (
              <QualifyLeadScreen
                onAnalyzeLead={handleAnalyzeLead}
                onBackToDashboard={() => handleNavigate('dashboard')}
              />
            )}

            {activeScreen === 'results' && activeAnalysis && (
              <ResultsScreen
                analysis={activeAnalysis}
                onBackToDashboard={() => handleNavigate('dashboard')}
                onQualifyAnother={() => handleNavigate('qualify')}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {activeScreen !== 'welcome' && (
        <MobileBottomNav activeScreen={activeScreen} onNavigate={handleNavigate} />
      )}
      <OfflineIndicator />
    </div>
  );
}
